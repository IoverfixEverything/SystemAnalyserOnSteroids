# Changelog

## v5.2-lightweight

- Removed runtime-irrelevant PowerShell comments from the main script.
- Fixed remaining German UI/report strings.
- Corrected progress accounting in the storage-junk section.
- Made event log truncation null-safe.
- Made scheduled-task info calls explicit with `-InputObject`.
- Reduced memory use in recursive folder-size measurement.
- Added small null-safety improvements for date, CPU, RAM, disk, GPU, and font-path handling.


## v5.1-public-en

- Converted the complete public package to English.
- Renamed the main script to `gaming_full_diagnostics.ps1`.
- Renamed the launcher to `Start-Diagnostics.cmd`.
- Changed the default output folder to `GamingFullDiagnostics`.
- Changed the default report filename prefix to `gaming_full_diagnostics_`.
- Kept Windows 11 / PowerShell 5.1 compatibility.
- Kept administrator self-elevation for complete diagnostics.
- Kept language-pack compatibility improvements by using Known Folders, CIM, registry data, and raw values where practical.

## v5.0-public

- Public/GitHub-ready Windows 11 version.
- Removed user-specific paths and personal branding.
- Added UAC self-elevation for full diagnostics.
- Added dynamic Known-Folder-based output path.
- Added timestamped report filenames.
- Added command-line parameters: `-OutDir`, `-OutFile`, `-EventDays`, `-SkipDxDiag`, `-NoElevate`, `-NoPause`.
- Improved compatibility with localized Windows installations by preferring CIM/registry/raw values over localized display strings where practical.
- Added README and .gitignore.
