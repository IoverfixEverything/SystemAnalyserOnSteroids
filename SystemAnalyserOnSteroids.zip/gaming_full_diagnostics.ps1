[CmdletBinding()]
param(
    [string]$OutFile = '',
    [string]$OutDir = '',
    [switch]$NoElevate,
    [switch]$NoPause,
    [switch]$SkipDxDiag,
    [switch]$SkipStorageScan,
    [switch]$Redact,            # Best-effort redaction of structured PII fields (hostname, user, MACs, serials, IPs)
    [switch]$GenerateTemplate,  # Also write a user_problem_template.txt questionnaire next to the report
    [switch]$SelfTest,          # Verify write access, admin, DxDiag, CIM, Event Log before scanning
    [ValidateRange(1,365)][int]$EventDays = 45,
    [ValidateRange(5,600)][int]$StorageScanTimeout = 45
)

function Test-IsAdministrator {
    try {
        $identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Add-QuotedArg {
    param([string]$Name,[string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return '' }
    $safe = $Value -replace '"','\"'
    return " $Name `"$safe`""
}

if (-not $NoElevate -and -not (Test-IsAdministrator)) {
    $self = $PSCommandPath
    if ([string]::IsNullOrWhiteSpace($self)) { $self = $MyInvocation.MyCommand.Path }
    if ([string]::IsNullOrWhiteSpace($self)) {
        Write-Host 'ERROR: Could not determine the script path. Please run as administrator.' -ForegroundColor Red
        exit 1
    }

    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $psExe)) { $psExe = 'powershell.exe' }

    # NOTE: must NOT use $args -- it is a PowerShell automatic variable (unbound positional params).
    $elevArgs = "-NoProfile -ExecutionPolicy Bypass -File `"$self`""
    $elevArgs += Add-QuotedArg '-OutFile' $OutFile
    $elevArgs += Add-QuotedArg '-OutDir'  $OutDir
    if ($NoPause)         { $elevArgs += ' -NoPause' }
    if ($SkipDxDiag)      { $elevArgs += ' -SkipDxDiag' }
    if ($SkipStorageScan) { $elevArgs += ' -SkipStorageScan' }
    if ($Redact)          { $elevArgs += ' -Redact' }
    if ($GenerateTemplate){ $elevArgs += ' -GenerateTemplate' }
    if ($SelfTest)        { $elevArgs += ' -SelfTest' }
    $elevArgs += " -EventDays $EventDays"
    $elevArgs += " -StorageScanTimeout $StorageScanTimeout"

    try {
        Start-Process -FilePath $psExe -ArgumentList $elevArgs -Verb RunAs -WorkingDirectory (Get-Location).Path -ErrorAction Stop
        exit 0
    } catch {
        Write-Host "ERROR: UAC elevation was cancelled or failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

Set-StrictMode -Off
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { $OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Get-PreferredOutputDirectory {
    param([string]$RequestedOutDir)

    $candidates = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($RequestedOutDir)) {
        $candidates.Add([Environment]::ExpandEnvironmentVariables($RequestedOutDir))
    }

    try {
        $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
        if (-not [string]::IsNullOrWhiteSpace($desktop)) { $candidates.Add((Join-Path $desktop 'GamingFullDiagnostics')) }
    } catch {}

    try {
        $docs = [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)
        if (-not [string]::IsNullOrWhiteSpace($docs)) { $candidates.Add((Join-Path $docs 'GamingFullDiagnostics')) }
    } catch {}

    if (-not [string]::IsNullOrWhiteSpace($env:TEMP)) { $candidates.Add((Join-Path $env:TEMP 'GamingFullDiagnostics')) }

    foreach ($candidate in $candidates) {
        try {
            $full = [System.IO.Path]::GetFullPath($candidate)
            if (-not (Test-Path $full)) { New-Item -ItemType Directory -Path $full -Force | Out-Null }
            $probe = Join-Path $full ('.write_test_{0}.tmp' -f ([guid]::NewGuid().ToString('N')))
            Set-Content -Path $probe -Value 'ok' -Encoding UTF8 -ErrorAction Stop
            Remove-Item $probe -Force -ErrorAction SilentlyContinue
            return $full
        } catch {}
    }
    throw 'No writable output directory found.'
}

function Resolve-OutputFilePath {
    param([string]$RequestedOutFile,[string]$RequestedOutDir)

    if (-not [string]::IsNullOrWhiteSpace($RequestedOutFile)) {
        $expanded = [Environment]::ExpandEnvironmentVariables($RequestedOutFile)
        $full = [System.IO.Path]::GetFullPath($expanded)
        $parent = Split-Path -Parent $full
        if ([string]::IsNullOrWhiteSpace($parent)) { $parent = (Get-Location).Path }
        if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        return $full
    }

    $dir = Get-PreferredOutputDirectory -RequestedOutDir $RequestedOutDir
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    return (Join-Path $dir ("gaming_full_diagnostics_{0}.txt" -f $stamp))
}

function ConvertTo-InvariantBoolState {
    param($Value)
    if ($null -eq $Value) { return 'Unknown' }
    if ($Value -is [array]) { $Value = ($Value -join ',') }
    $s = ("$Value").Trim().ToLowerInvariant()
    switch -Regex ($s) {
        # ASCII-only patterns -- non-ASCII chars (si with accent, wl/aczone with diacritics) are
        # intentionally omitted to prevent encoding corruption on ANSI/CP1252 systems.
        # The ASCII fallbacks (si, wlaczone, wylaczone, nao) already cover those locales.
        '^(1|true|yes|y|on|enabled|enable|aktiviert|ein|oui|si|sim|ja|aan|wlaczone|ativado|activado|abilitato)$' { return 'Enabled' }
        '^(0|false|no|n|off|disabled|disable|deaktiviert|aus|non|nao|nee|uit|wylaczone|desativado|desactivado|disabilitato)$' { return 'Disabled' }
        default { return 'Unknown' }
    }
}

function Test-NetAdapterPropertyEnabled {
    param($Property)
    if ($null -eq $Property) { return $false }
    $rawState = ConvertTo-InvariantBoolState $Property.RegistryValue
    if ($rawState -eq 'Enabled') { return $true }
    if ($rawState -eq 'Disabled') { return $false }
    $displayState = ConvertTo-InvariantBoolState $Property.DisplayValue
    return ($displayState -eq 'Enabled')
}

function Test-NetAdapterPropertyDisabled {
    param($Property)
    if ($null -eq $Property) { return $false }
    $rawState = ConvertTo-InvariantBoolState $Property.RegistryValue
    if ($rawState -eq 'Disabled') { return $true }
    if ($rawState -eq 'Enabled') { return $false }
    $displayState = ConvertTo-InvariantBoolState $Property.DisplayValue
    return ($displayState -eq 'Disabled')
}

function Nz { param($v,[string]$fb='') ; if ($null -eq $v -or "$v" -eq '') { return $fb } ; return "$v" }

function Format-DateValue {
    param($Value,[string]$Format='yyyy-MM-dd HH:mm:ss',[string]$Fallback='N/A')
    try {
        if ($null -eq $Value) { return $Fallback }
        return ([datetime]$Value).ToString($Format)
    } catch { return $Fallback }
}

function ShortText {
    param($Value,[int]$MaxLength=200)
    $text = (Nz $Value) -replace '\r?\n',' '
    if ($text.Length -gt $MaxLength) { return ($text.Substring(0,$MaxLength) + '...') }
    return $text
}

$script:buf        = [System.Collections.Generic.List[string]]::new()
$script:findings   = [System.Collections.Generic.List[object]]::new()
$script:limitations= [System.Collections.Generic.List[string]]::new()

# Structured data collected during scan -> serialized to JSON at end
$script:sysInfo = [ordered]@{
    schema_version  = '1.0'
    script_version  = 'v5.2-lightweight'
    generated_utc   = ''
    report_txt      = ''
    is_admin        = (Test-IsAdministrator)
    is_64bit_proc   = [Environment]::Is64BitProcess
    ps_version      = "$($PSVersionTable.PSVersion)"
    ps_host         = $Host.Name
    redacted        = $Redact.IsPresent
    hostname        = ''
    username        = ''
    os              = [ordered]@{}
    cpu             = [ordered]@{}
    ram             = [ordered]@{}
    gpu             = [System.Collections.Generic.List[object]]::new()
    storage         = [System.Collections.Generic.List[object]]::new()
    bios            = [ordered]@{}
    security        = [ordered]@{}
    power_plan      = ''
    limitations     = $null   # will be replaced with array at end
    findings        = $null   # will be replaced with array at end
    recent_changes  = [ordered]@{updates=@();driver_changes=@();crashes=@()}
    ai_instructions = 'Analyse this report to identify root causes of system issues. Prioritise Critical and High severity findings with High confidence. Cross-reference recent_changes timestamps with when symptoms began. Do not recommend OS reinstall unless multiple Critical/High-confidence findings indicate hardware corruption or severe OS damage. Flag any finding where evidence is ambiguous as requiring manual confirmation.'
}

# Helper: redact a string when -Redact is active. Use for hostnames, usernames, MACs, serials.
function Redact-Val {
    param([string]$Value, [string]$Placeholder = '[REDACTED]')
    if ($Redact -and -not [string]::IsNullOrWhiteSpace($Value)) { return $Placeholder }
    return $Value
}

# Helper: redact IP addresses from a string.
function Redact-IPs {
    param([string]$Text)
    if (-not $Redact) { return $Text }
    $Text = $Text -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b','[IP-REDACTED]'
    $Text = $Text -replace '\b([0-9A-Fa-f]{2}[:\-]){5}[0-9A-Fa-f]{2}\b','[MAC-REDACTED]'
    return $Text
}

function W {
    param([string]$s='')
    $script:buf.Add($s)
    if ($script:buf.Count -ge 400) { FlushBuf }
}
function FlushBuf {
    if ($script:buf.Count -gt 0) {
        try {
            Add-Content -Path $OutFile -Value $script:buf -Encoding UTF8 -ErrorAction Stop
        } catch {
            Write-Host "[ERROR] FlushBuf: could not write to output file: $($_.Exception.Message)" -ForegroundColor Red
        }
        $script:buf.Clear()
    }
}

# Reads the (default) value of a registry key via the .NET registry API.
# More reliable than (Get-ItemProperty $path).'(default)' which can throw
# PropertyNotFoundException when the default value is simply not set.
function Get-RegDefaultValue {
    param([string]$Path)
    try {
        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
        return $key.GetValue($null)   # $null = the unnamed/default value
    } catch { return $null }
}

function Add-Finding {
    param(
        [ValidateSet('Critical','High','Medium','Low','Info')][string]$Sev,
        [string]$Cat,
        [string]$Title,
        [string]$Evidence = '',
        [string]$Rec = '',
        [ValidateSet('High','Medium','Low')][string]$Confidence = 'Medium'
    )
    $script:findings.Add([PSCustomObject]@{
        Severity       = $Sev
        Confidence     = $Confidence
        Category       = $Cat
        Title          = $Title
        Evidence       = $Evidence
        Recommendation = $Rec
    })
}

function Add-Limitation {
    param([string]$Text)
    $script:limitations.Add($Text)
    Note "[LIMITATION] $Text"
}

function Sec {
    param([string]$n,[string]$t,[string]$d='')
    W ''; W ('=' * 72); W "  [$n] $t"
    if ($d) { W "       $d" }
    W ('=' * 72)
    Write-Host '' ; Write-Host "[$n] $t" -ForegroundColor Yellow
}
function Sub  { param([string]$t) W ''; W "  --- $t ---" }
function Row  { param([string]$k,[string]$v) W ("  {0,-40} {1}" -f ($k+':'),$v) }
function Div  { W ('  ' + '-'*70) }
$script:stepTotal   = 26
$script:stepCurrent = 0
$script:stepName    = ''
$script:subName     = ''
$script:subTimer    = $null

function Prog {
    param([string]$s)
    $script:stepCurrent++
    $script:stepName = $s
    $script:subName  = ''

    $pct   = [math]::Round(($script:stepCurrent / $script:stepTotal) * 100)
    $filled = [math]::Round($pct / 5)
    $empty  = 20 - $filled
    $bar   = '[' + ('#' * $filled) + ('-' * $empty) + ']'

    Write-Host ''
    Write-Host ("  $bar  {0,3}%  ({1}/{2})" -f $pct, $script:stepCurrent, $script:stepTotal) -ForegroundColor Green
    Write-Host "  $s" -ForegroundColor Cyan
    $script:subTimer = Get-Date
}

function ProgSub {
    param([string]$s)
    $script:subName = $s
    $elapsed = if ($script:subTimer) { [math]::Round(((Get-Date)-$script:subTimer).TotalSeconds,1) } else { 0 }
    Write-Host ("    -> {0,-55} [{1}s]" -f $s, $elapsed) -ForegroundColor DarkCyan
    $script:subTimer = Get-Date
}
function Err  { param([string]$s) W "  [ERROR] $s" ; Write-Host "  [ERROR] $s" -ForegroundColor Red }
function Note { param([string]$s) W "  [INFO] $s" }

$script:systemExes = @('rundll32','regsvr32','cmd','powershell','pwsh','wscript','cscript','explorer','control','msiexec','svchost','lsass')
function Resolve-Exe {
    param([string]$cmd)
    if (-not $cmd -or $cmd.Trim() -eq '') { return '' }
    $e = [Environment]::ExpandEnvironmentVariables($cmd.Trim())
    $e = $e -replace '^\\SystemRoot\\', "$env:WINDIR\"
    $e = $e -replace '^\\SystemRoot',   "$env:WINDIR"
    if ($e.StartsWith('"')) {
        $end = $e.IndexOf('"', 1)
        if ($end -gt 0) { return $e.Substring(1, $end-1) }
    }
    $parts = $e -split '\s+'
    $acc = ''
    foreach ($p in $parts) {
        $acc = if ($acc) { "$acc $p" } else { $p }
        if (Test-Path $acc -EA 0)                           { return $acc }
        if ($acc -match '\.(exe|com|bat|cmd|ps1|vbs|msi)$') { return $acc }
    }
    return $parts[0]
}

function Test-ExeExists {
    param([string]$cmd)
    if (-not $cmd) { return $false }
    $exe = Resolve-Exe $cmd
    if (-not $exe) { return $false }
    $base = [System.IO.Path]::GetFileNameWithoutExtension($exe).ToLower()
    if ($script:systemExes -contains $base) { return $true }
    if (Test-Path $exe -EA 0)              { return $true }
    $gcmd = Get-Command $exe -EA 0
    return ($null -ne $gcmd)
}

function Resolve-Dll {
    param([string]$dll)
    if (-not $dll) { return '' }
    $d = [Environment]::ExpandEnvironmentVariables($dll.Trim().Trim('"'))
    $d = $d -replace '^\\SystemRoot\\', "$env:WINDIR\"
    if ($d -notmatch '\\') { return (Join-Path $env:SystemRoot "System32\$d") }
    return $d
}

function Get-AR {
    param([int]$w,[int]$h)
    if ($w-le0-or$h-le0) { return 'N/A' }
    $r = $w/$h
    if ([math]::Abs($r-32/9)-lt0.02)  { return '32:9'  }
    if ([math]::Abs($r-21/9)-lt0.05)  { return '21:9'  }
    if ([math]::Abs($r-16/9)-lt0.01)  { return '16:9'  }
    if ([math]::Abs($r-16/10)-lt0.01) { return '16:10' }
    if ([math]::Abs($r-4/3)-lt0.01)   { return '4:3'   }
    $a=$w;$b=$h; while($b){$t=$b;$b=$a%$b;$a=$t}
    return "$($w/$a):$($h/$a)"
}

function Describe-Trigger {
    param($trig)
    if (-not $trig) { return 'No trigger' }
    $type = $trig.CimClass.CimClassName -replace '.*MSFT_Task',''
    $sb   = Nz $trig.StartBoundary
    $en   = Nz $trig.Enabled
    $rep  = if ($trig.Repetition -and $trig.Repetition.Interval) { " | Repeat:$(Nz $trig.Repetition.Interval)" } else {''}
    $delay= if ($trig.Delay) { " | Delay:$(Nz $trig.Delay)" } else {''}
    $extra = switch -Wildcard ($type) {
        'LogonTrigger'       { " | User:$(Nz $trig.UserId 'Every')" }
        'EventTrigger'       { " | Subscription:$((Nz $trig.Subscription) -replace '\s+',' ')" }
        'DailyTrigger'       { " | Every $(Nz $trig.DaysInterval 1) day(s)" }
        'WeeklyTrigger'      { " | Weekdays:$(Nz $trig.DaysOfWeek)" }
        'SessionState*'      { " | State:$(Nz $trig.StateChange)" }
        default              { '' }
    }
    return "$type | Start:$sb$extra$rep$delay | Enabled:$en"
}

function Print-Task {
    param($task,[string]$cat='')
    $fn   = "$(Nz $task.TaskPath)$(Nz $task.TaskName)"
    $info = Get-ScheduledTaskInfo -InputObject $task -EA 0
    Div
    W "  TASK:    $fn"
    if ($cat) { W "  CAT:     $cat" }
    Row 'Status'       (Nz $task.State)
    Row 'Author'        (Nz $task.Author)
    $dsc = (Nz $task.Description) -replace '\r?\n',' '
    if ($dsc.Length -gt 150) { $dsc = $dsc.Substring(0,150)+'...' }
    Row 'Description'      $dsc
    if ($task.Settings) {
        Row 'Hidden'    (Nz $task.Settings.Hidden)
        Row 'Priority'   (Nz $task.Settings.Priority)
        Row 'Time limit'    (Nz $task.Settings.ExecutionTimeLimit 'None')
        Row 'WakeToRun'    (Nz $task.Settings.WakeToRun)
        Row 'Multi-inst.'  (Nz $task.Settings.MultipleInstances)
    }
    if ($task.Principal) {
        Row 'RunAs'     "$(Nz $task.Principal.UserId) | LogonType:$(Nz $task.Principal.LogonType) | Level:$(Nz $task.Principal.RunLevel)"
    }
    if ($task.Triggers) {
        $ti=0
        foreach ($trig in $task.Triggers) { $ti++ ; Row "Trigger $ti" (Describe-Trigger $trig) }
    } else { Row 'Trigger' 'None' }
    if ($task.Actions) {
        $ai=0
        foreach ($action in $task.Actions) {
            $ai++
            $at = $action.CimClass.CimClassName -replace '.*MSFT_Task',''
            if ($at -match 'ExecAction') {
                $exe  = Nz $action.Execute
                $args = Nz $action.Arguments
                $exeOk = Test-ExeExists $exe
                Row "Action $ai Exe"  "$exe  [$(if($exeOk){'OK'}else{'EXE MISSING'})]"
                if ($args) { Row "Action $ai Args" $args }
                if (-not $exeOk -and $exe -match '^[A-Za-z]:\\') { Add-Finding 'Medium' 'Scheduler' "Task EXE missing: $fn" $exe 'Software may have been uninstalled; verify or disable the task.' }
            } elseif ($at -match 'ComHandler') {
                Row "Action $ai COM" "$(Nz $action.ClassId)"
            }
        }
    }
    if ($info) {
        $lr = if ($info.LastRunTime -and $info.LastRunTime.Year -gt 2000) { $info.LastRunTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'Never' }
        $nr = if ($info.NextRunTime -and $info.NextRunTime.Year -gt 2000) { $info.NextRunTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'N/A' }
        $res = '0x{0:X8}' -f [uint32]$info.LastTaskResult
        $rs = if ($info.LastTaskResult -eq 0) { 'OK' } elseif ($info.LastTaskResult -eq 267011) { 'Never run' } else { "ERROR ($res)" }
        if ($info.LastTaskResult -ne 0 -and $info.LastTaskResult -ne 267011) {
            Add-Finding 'Low' 'Scheduler' "Task failed: $fn" "LastResult=$res" 'Check task error.'
        }
        Row 'Last run'    $lr
        Row 'Result'        $rs
        Row 'Next run'  $nr
        Row 'Missed runs' (Nz $info.NumberOfMissedRuns)
    }
    W ''
}

function Parse-EDID {
    param([byte[]]$e)
    if (-not $e -or $e.Length -lt 128) { return $null }
    $hdr=@(0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00)
    for ($i=0;$i-lt8;$i++) { if ($e[$i]-ne$hdr[$i]) { return @{Error='Header'} } }
    $m1=($e[8]-shr2)-band0x1F; $m2=(($e[8]-band0x03)-shl3)-bor(($e[9]-shr5)-band0x07); $m3=$e[9]-band0x1F
    $mfr=[char]($m1+64)+[char]($m2+64)+[char]($m3+64)
    $prodCode=($e[11]-shl8)-bor$e[10]; $year=$e[17]+1990; $week=$e[16]; $ver="$($e[18]).$($e[19])"
    $dig=($e[20]-band0x80)-ne0
    $bd=switch(($e[20]-shr4)-band7){0{'?'} 1{'6b'} 2{'8b'} 3{'10b'} 4{'12b'} default{'?'}}
    $vi=switch($e[20]-band0xF){1{'DVI'} 2{'HDMIa'} 3{'HDMIb'} 5{'DP'} default{'?'}}
    $hCm=$e[21];$vCm=$e[22]
    $diagIn=if($hCm-and$vCm){[math]::Round([math]::Sqrt($hCm*$hCm+$vCm*$vCm)/2.54,1)}else{0}
    $gamma=if($e[23]-eq0xFF){'InExt'}else{[math]::Round(($e[23]+100)/100.0,2)}
    $stdT=@()
    for($i=0;$i-lt8;$i++){
        $b1=$e[38+$i*2];$b2=$e[39+$i*2]
        if($b1-eq1-and$b2-eq1){continue}
        $hA=($b1+31)*8; $ac=($b2-shr6)-band3
        $ar=switch($ac){0{'16:10'} 1{'4:3'} 2{'5:4'} 3{'16:9'}}
        $vA=switch($ac){0{[int]($hA*10/16)} 1{[int]($hA*3/4)} 2{[int]($hA*4/5)} 3{[int]($hA*9/16)}}
        $vR=($b2-band0x3F)+60; $stdT+="${hA}x${vA}@${vR}Hz($ar)"
    }
    $detT=@(); $mnName=''; $mnSerial=''; $minV=$null; $maxV=$null; $minH=$null; $maxH=$null; $maxPix=$null
    for($di=0;$di-lt4;$di++){
        $b=54+$di*18; $pix=$e[$b]+$e[$b+1]*256
        if($pix-ne0){
            $hA=$e[$b+2]+(($e[$b+4]-shr4)-shl8); $hBl=$e[$b+3]+(($e[$b+4]-band0xF)-shl8)
            $vA=$e[$b+5]+(($e[$b+7]-shr4)-shl8); $vBl=$e[$b+6]+(($e[$b+7]-band0xF)-shl8)
            $hFP=$e[$b+8]; $hSW=$e[$b+9]; $vFP=($e[$b+10]-shr4)-band0xF; $vSW=$e[$b+10]-band0xF
            $hT=$hA+$hBl; $vT=$vA+$vBl; $pixHz=$pix*10000
            $rr=if($hT-and$vT){[math]::Round($pixHz/($hT*$vT),3)}else{0}
            $hMM=$e[$b+12]+(($e[$b+14]-shr4)-shl8); $vMM=$e[$b+13]+(($e[$b+14]-band0xF)-shl8)
            $detT+=@{hA=$hA;vA=$vA;hBl=$hBl;vBl=$vBl;hFP=$hFP;hSW=$hSW;vFP=$vFP;vSW=$vSW;hT=$hT;vT=$vT;PixMHz=[math]::Round($pixHz/1e6,3);RR=$rr;hMM=$hMM;vMM=$vMM;Int=($e[$b+17]-band0x80)-ne0}
        } else {
            $tag=$e[$b+3]; $raw=$e[($b+5)..($b+17)]
            switch($tag){
                0xFF{$mnSerial=[System.Text.Encoding]::ASCII.GetString($raw).Trim().TrimEnd([char]10)}
                0xFD{$minV=$e[$b+5];$maxV=$e[$b+6];$minH=$e[$b+7];$maxH=$e[$b+8];$maxPix=$e[$b+9]*10}
                0xFC{$mnName=[System.Text.Encoding]::ASCII.GetString($raw).Trim().TrimEnd([char]10)}
            }
        }
    }
    return @{Mfr=$mfr;Prod=('0x{0:X4}'-f$prodCode);Name=$mnName;Serial=$mnSerial;Year=$year;Week=$week;Ver=$ver;Digital=$dig;BD=$bd;VI=$vi;hCm=$hCm;vCm=$vCm;DiagIn=$diagIn;Gamma=$gamma;StdT=$stdT;DetT=$detT;MinV=$minV;MaxV=$maxV;MinH=$minH;MaxH=$maxH;MaxPix=$maxPix}
}

$startTime = Get-Date
try {
    $OutFile = Resolve-OutputFilePath -RequestedOutFile $OutFile -RequestedOutDir $OutDir
    $outDir  = Split-Path -Parent $OutFile
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
} catch {
    Write-Host "ERROR: Could not prepare output target: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

try {
    Set-Content -Path $OutFile -Value @"
========================================================================
  WINDOWS 11 GAMING FULL DIAGNOSTICS v5.2-lightweight
  Created:     $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  Scope: Gaming, Display/EDID/Timings, registry issues,
                scheduled tasks, drivers, event logs, crashes
  PS-Version:   $($PSVersionTable.PSVersion)
  Admin:        $(Test-IsAdministrator)
  Output:      $OutFile
  Event range: last $EventDays days
  NOTE: Read-only - no changes are made.
========================================================================
"@ -Encoding UTF8 -ErrorAction Stop
} catch {
    Write-Host "ERROR: Could not write output file header: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
# Verify the initial write produced a non-empty file
if (-not (Test-Path $OutFile) -or (Get-Item $OutFile -EA 0).Length -eq 0) {
    Write-Host 'ERROR: Output file is empty after initial write. Check disk space and permissions.' -ForegroundColor Red
    exit 1
}

# ---- SELF-TEST MODE -------------------------------------------------------
if ($SelfTest) {
    Write-Host ''
    Write-Host '=== SELF-TEST MODE ===' -ForegroundColor Yellow
    $stPass = $true
    function ST { param([bool]$ok,[string]$msg) $c=if($ok){'Green'}else{'Red'}; $s=if($ok){'PASS'}else{'FAIL'}; Write-Host "  [$s] $msg" -ForegroundColor $c; if(-not $ok){$script:stPass=$false} }
    ST (Test-IsAdministrator)               'Running as Administrator'
    ST ([Environment]::Is64BitProcess)      '64-bit process'
    $wt = try { Set-Content -Path (Join-Path $outDir '.selftest') -Value 'ok' -EA Stop; Remove-Item (Join-Path $outDir '.selftest') -EA 0; $true } catch { $false }
    ST $wt                                  "Write access to output dir: $outDir"
    $dxOk = (Get-Command dxdiag -EA 0) -ne $null
    ST $dxOk                                'DxDiag available'
    $cimOk = try { Get-CimInstance Win32_OperatingSystem -EA Stop | Out-Null; $true } catch { $false }
    ST $cimOk                               'CIM/WMI available'
    $evtOk = try { Get-WinEvent -LogName System -MaxEvents 1 -EA Stop | Out-Null; $true } catch { $false }
    ST $evtOk                               'Event Log accessible'
    $regOk = try { Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -EA Stop | Out-Null; $true } catch { $false }
    ST $regOk                               'Registry (HKLM) accessible'
    Write-Host ''
    if ($stPass) { Write-Host 'All self-tests PASSED. Safe to run full scan.' -ForegroundColor Green }
    else         { Write-Host 'One or more tests FAILED. Results may be incomplete.' -ForegroundColor Red }
    Write-Host ''
    if (-not $NoPause -and $Host.Name -eq 'ConsoleHost') {
        Write-Host 'Press Enter to continue with full scan, or close window to abort.' -ForegroundColor DarkGray
        try { [void][Console]::ReadLine() } catch {}
    }
}
# ---------------------------------------------------------------------------

# Populate sysInfo header fields (used in JSON output)
$script:sysInfo.generated_utc = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
$script:sysInfo.report_txt    = $OutFile
$script:sysInfo.hostname      = Redact-Val $env:COMPUTERNAME '[HOST-REDACTED]'
$script:sysInfo.username      = Redact-Val $env:USERNAME      '[USER-REDACTED]'

$script:dxProc = $null
$dxFile = Join-Path $outDir 'dxdiag_raw.txt'
if ($SkipDxDiag) {
    Write-Host 'DxDiag is being skipped (-SkipDxDiag).' -ForegroundColor DarkYellow
} else {
    if (Test-Path $dxFile) { Remove-Item $dxFile -Force -EA 0 }
    try {
        # -PassThru gives us the process object so J01 can call WaitForExit() instead of polling
        $script:dxProc = Start-Process 'dxdiag' -ArgumentList "/t `"$dxFile`"" -WindowStyle Hidden -PassThru -ErrorAction Stop
        Write-Host "DxDiag started (PID: $($script:dxProc.Id)). Will wait in section J01." -ForegroundColor DarkCyan
    } catch {
        Write-Host "Could not start DxDiag: $($_.Exception.Message)" -ForegroundColor DarkYellow
    }
}

Sec 'A01' 'SYSTEM BASICS' 'OS, CPU, RAM, GPU, Mainboard, BIOS, Storage'
Prog '[A01] System basics...'
try {
    $os    = Get-CimInstance Win32_OperatingSystem
    $cs    = Get-CimInstance Win32_ComputerSystem
    $bios  = Get-CimInstance Win32_BIOS
    $board = Get-CimInstance Win32_BaseBoard
    Row 'Hostname/User'    "$(Redact-Val $env:COMPUTERNAME '[HOST]')  |  $(Redact-Val $env:USERNAME '[USER]')"
    Row 'OS'               "$(Nz $os.Caption)  $(Nz $os.OSArchitecture)"
    Row 'Build'            "$(Nz $os.BuildNumber)  |  v$(Nz $os.Version)"
    Row 'Install date'     (Format-DateValue $os.InstallDate 'yyyy-MM-dd')
    Row 'Last boot'     (Format-DateValue $os.LastBootUpTime 'yyyy-MM-dd HH:mm:ss')
    $uptime = if ($os.LastBootUpTime) { "$([math]::Round(((Get-Date)-$os.LastBootUpTime).TotalHours,1))h" } else { 'N/A' }
    Row 'Uptime'           $uptime
    Row 'Total RAM'       "$([math]::Round($cs.TotalPhysicalMemory/1GB,1)) GB"
    Row 'Mainboard'        "$(Nz $board.Manufacturer)  $(Nz $board.Product)"
    Row 'BIOS'             "$(Nz $bios.Manufacturer)  $(Nz $bios.SMBIOSBIOSVersion)  $(Format-DateValue $bios.ReleaseDate 'yyyy-MM-dd')"

    # BIOS age warning
    $biosDateStr = Format-DateValue $bios.ReleaseDate 'yyyy-MM-dd'
    if ($bios.ReleaseDate -and ([DateTime]$bios.ReleaseDate) -lt (Get-Date).AddYears(-3)) {
        Add-Finding 'Low' 'BIOS' "BIOS is over 3 years old" "Date: $biosDateStr" 'Check manufacturer site for updates; old BIOS may miss security patches, XMP profiles, or CPU support.' -Confidence 'High'
    }

    # Secure Boot
    $secBoot = 'Unknown'
    try { $secBoot = (Confirm-SecureBootUEFI -EA Stop).ToString() } catch { $secBoot = 'N/A (Legacy BIOS or cmdlet unavailable)' }
    Row 'Secure Boot'      $secBoot

    # UEFI vs Legacy
    $fwType = try { (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control' -EA Stop).PEFirmwareType } catch { $null }
    $fwStr  = switch ($fwType) { 1 { 'BIOS (Legacy)' } 2 { 'UEFI' } default { 'Unknown' } }
    Row 'Firmware type'    $fwStr

    # TPM
    $tpmVer = 'None/Unknown'
    try {
        $tpm = Get-CimInstance -Namespace root\CIMV2\Security\MicrosoftTpm -ClassName Win32_Tpm -EA Stop
        $tpmVer = if ($tpm) { "Present  v$(Nz $tpm.SpecVersion)" } else { 'Not detected' }
    } catch { $tpmVer = 'Query failed (not elevated or not present)' }
    Row 'TPM'              $tpmVer

    # Virtualization (Hyper-V / VT-x enabled in firmware)
    $vmFeat = try { (Get-CimInstance Win32_Processor -EA 0 | Select-Object -First 1).VirtualizationFirmwareEnabled } catch { $null }
    $vmStr  = if ($null -ne $vmFeat) { if ($vmFeat) { 'Enabled in firmware' } else { 'Disabled in firmware' } } else { 'Unknown' }
    Row 'Virtualization'   $vmStr

    # Populate sysInfo
    $script:sysInfo.os = [ordered]@{
        caption      = Nz $os.Caption
        architecture = Nz $os.OSArchitecture
        build        = Nz $os.BuildNumber
        version      = Nz $os.Version
        last_boot    = Format-DateValue $os.LastBootUpTime 'yyyy-MM-ddTHH:mm:ss'
        uptime_h     = if ($os.LastBootUpTime) { [math]::Round(((Get-Date)-$os.LastBootUpTime).TotalHours,1) } else { $null }
        total_ram_gb = [math]::Round($cs.TotalPhysicalMemory/1GB,1)
    }
    $script:sysInfo.bios = [ordered]@{
        vendor       = Nz $bios.Manufacturer
        version      = Nz $bios.SMBIOSBIOSVersion
        date         = $biosDateStr
        secure_boot  = $secBoot
        firmware     = $fwStr
        tpm          = $tpmVer
        virt_enabled = $vmStr
        board        = "$(Nz $board.Manufacturer) $(Nz $board.Product)"
    }
} catch { Err "A01: $($_.Exception.Message)"; Add-Limitation "A01 system basics query failed: $($_.Exception.Message)" }

Sub 'CPU'
try {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    Row 'CPU'       ((Nz $cpu.Name).Trim())
    Row 'Cores/threads' "$($cpu.NumberOfCores) / $($cpu.NumberOfLogicalProcessors)"
    Row 'Max/current'  "$($cpu.MaxClockSpeed) / $($cpu.CurrentClockSpeed) MHz"
    Row 'L2/L3'     "$($cpu.L2CacheSize) KB / $($cpu.L3CacheSize) KB"
    $parkKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583'
    $parkVal = Nz (Get-ItemProperty $parkKey -EA 0).ValueMax '?'
    Row 'CPU parking' "$parkVal%  (0=disabled, gaming target)"
    if ($parkVal -ne '0' -and $parkVal -ne '?') { Add-Finding 'Low' 'CPU' 'CPU core parking enabled' "ValueMax=$parkVal%" 'Set to 0% for gaming latency.' -Confidence 'High' }
    $script:sysInfo.cpu = [ordered]@{
        name    = (Nz $cpu.Name).Trim()
        cores   = $cpu.NumberOfCores
        threads = $cpu.NumberOfLogicalProcessors
        max_mhz = $cpu.MaxClockSpeed
        core_parking = $parkVal
    }
} catch { Err "CPU: $($_.Exception.Message)" }

Sub 'RAM + XMP / EXPO status'
try {
    $slots = Get-CimInstance Win32_PhysicalMemory
    $ramList = [System.Collections.Generic.List[object]]::new()
    foreach ($s in $slots) {
        # ConfiguredClockSpeed = actual running speed set by BIOS (XMP/EXPO or JEDEC).
        # Speed                = module SPD rated speed (what's printed on the stick).
        # Always show both so the user can spot XMP being disabled.
        $rated   = Nz $s.Speed 0
        $running = Nz $s.ConfiguredClockSpeed 0
        $xmpHint = if ($running -gt 0 -and $rated -gt 0 -and [int]$running -lt ([int]$rated - 100)) { '  [XMP/EXPO OFF?]' } else { '' }
        Row "Slot $(Nz $s.DeviceLocator)" "$([math]::Round($s.Capacity/1GB,0)) GB  |  Rated:${rated}MHz  Running:${running}MHz${xmpHint}  |  $((Nz $s.PartNumber).Trim())  |  $(Nz $s.Manufacturer)"
        $ramList.Add([ordered]@{
            locator    = Nz $s.DeviceLocator
            size_gb    = [math]::Round($s.Capacity/1GB,0)
            rated_mhz  = [int]$rated
            running_mhz= [int]$running
            part       = if ($Redact) { '[REDACTED]' } else { (Nz $s.PartNumber).Trim() }
            vendor     = Nz $s.Manufacturer
        })
    }
    # Use ConfiguredClockSpeed for actual running speed; fall back to Speed if unavailable
    $maxRunning = ($slots | Where-Object { $_.ConfiguredClockSpeed -gt 0 } | Measure-Object -Property ConfiguredClockSpeed -Maximum).Maximum
    $maxRated   = ($slots | Measure-Object -Property Speed -Maximum).Maximum
    if (-not $maxRunning) { $maxRunning = $maxRated }

    Row 'Actual running speed'  "$maxRunning MHz  (ConfiguredClockSpeed)"
    Row 'Module rated speed'    "$maxRated MHz  (SPD)"
    if ($maxRunning -gt 0 -and $maxRated -gt 0 -and $maxRunning -lt ($maxRated - 100)) {
        Add-Finding 'High' 'RAM' 'RAM running below module rated speed -- XMP/EXPO likely disabled' "Running:${maxRunning}MHz  Rated:${maxRated}MHz" 'Enable XMP/EXPO Profile 1 in BIOS/UEFI. This is a significant gaming performance loss.' -Confidence 'High'
    } elseif ($maxRunning -le 2133 -and $slots.Count -gt 0) {
        Add-Finding 'Medium' 'RAM' 'RAM running at JEDEC default (2133 MHz) -- XMP/EXPO may be disabled' "Running:${maxRunning}MHz" 'Enable XMP/EXPO Profile 1 in BIOS/UEFI if this kit is rated higher.' -Confidence 'Medium'
    }
    $script:sysInfo.ram = [ordered]@{
        total_gb     = [math]::Round(($slots | Measure-Object -Property Capacity -Sum).Sum/1GB,1)
        slot_count   = $slots.Count
        running_mhz  = [int]$maxRunning
        rated_mhz    = [int]$maxRated
        xmp_mismatch = ($maxRunning -gt 0 -and $maxRated -gt 0 -and $maxRunning -lt ($maxRated - 100))
        modules      = @($ramList)
    }
} catch { Err "RAM: $($_.Exception.Message)"; Add-Limitation "RAM WMI query failed" }

Sub 'GPU'
try {
    Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic' } | ForEach-Object {
        Row 'GPU'        $_.Name
        Row 'Driver'    "$(Nz $_.DriverVersion)  $(Format-DateValue $_.DriverDate 'yyyy-MM-dd')"
        Row 'VRAM'       "$([math]::Round($_.AdapterRAM/1MB,0)) MB"
        Row 'Resolution' "$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)  @$($_.CurrentRefreshRate)Hz  (Max:$($_.MaxRefreshRate)Hz)"
        Row 'Bpp'        "$($_.CurrentBitsPerPixel)"
        $ar = Get-AR ([int](Nz $_.CurrentHorizontalResolution 0)) ([int](Nz $_.CurrentVerticalResolution 0))
        Row 'Aspect'     $ar
        if ($_.CurrentRefreshRate -lt $_.MaxRefreshRate -and $_.MaxRefreshRate -gt 0) {
            Add-Finding 'Medium' 'Display' 'Monitor is NOT running at its maximum refresh rate' "Current:$($_.CurrentRefreshRate)Hz Max:$($_.MaxRefreshRate)Hz" 'Check display settings.' -Confidence 'High'
        }
        $driverDate = try { [datetime]$_.DriverDate } catch { $null }
        if ($driverDate -and $driverDate -lt (Get-Date).AddYears(-2)) {
            Add-Finding 'Medium' 'Driver' "GPU driver is over 2 years old" "Driver date: $(Format-DateValue $_.DriverDate 'yyyy-MM-dd')" 'Download latest GPU driver from NVIDIA/AMD/Intel site.' -Confidence 'High'
        }
        $script:sysInfo.gpu.Add([ordered]@{
            name        = Nz $_.Name
            driver_ver  = Nz $_.DriverVersion
            driver_date = Format-DateValue $_.DriverDate 'yyyy-MM-dd'
            vram_mb     = [math]::Round($_.AdapterRAM/1MB,0)
            current_hz  = $_.CurrentRefreshRate
            max_hz      = $_.MaxRefreshRate
        })
    }
} catch { Err "GPU: $($_.Exception.Message)" }

Sub 'Storage'
try {
    $diskDrives = Get-CimInstance Win32_DiskDrive
    foreach ($disk in $diskDrives) {
        # Determine drive type: NVMe -> PCIExpress, SSD -> Solid State tag, else HDD
        $iface     = Nz $disk.InterfaceType
        $mediaType = Nz $disk.MediaType
        $model     = (Nz $disk.Model).Trim()
        $diskType  = if ($iface -match 'PCI|NVMe' -or $model -match 'NVMe') { 'NVMe' }
                     elseif ($mediaType -match 'SSD|Solid' -or $model -match 'SSD') { 'SSD' }
                     elseif ($disk.Size -gt 0) { 'HDD (assumed)' }
                     else { 'Unknown' }
        Row 'Disk' "$model  $([math]::Round($disk.Size/1GB,0)) GB  [$diskType]  $iface  Serial:$(Redact-Val (Nz $disk.SerialNumber).Trim())"
    }
    try {
        $smart = Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus -EA Stop
        foreach ($s in $smart) {
            $pred = Nz $s.PredictFailure $false
            Row 'SMART FailPredict' "$pred  Reason:$(Nz $s.Reason 0)"
            if ($pred -eq $true) { Add-Finding 'Critical' 'Storage' 'SMART predicted drive failure!' "Disk: $($s.InstanceName)" 'Create a backup immediately!' -Confidence 'High' }
        }
    } catch { Add-Limitation 'SMART WMI (MSStorageDriver_FailurePredictStatus) unavailable -- drive health not checked' }

    # BitLocker status
    Sub 'BitLocker status'
    try {
        $blVol = Get-CimInstance -Namespace root\cimv2\Security\MicrosoftVolumeEncryption -ClassName Win32_EncryptableVolume -EA Stop
        foreach ($v in $blVol) {
            $blStatus = switch ($v.ProtectionStatus) { 0 {'OFF'} 1 {'ON'} 2 {'SUSPENDED'} default {'Unknown'} }
            Row "BitLocker $($v.DriveLetter)" "$blStatus  (ConversionStatus: $(Nz $v.ConversionStatus))"
        }
    } catch { Note 'BitLocker WMI unavailable (requires elevation or feature not present)' }

    Sub 'Logical drives'
    $diskStorageList = [System.Collections.Generic.List[object]]::new()
    Get-CimInstance Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 } | ForEach-Object {
        $f=[math]::Round($_.FreeSpace/1GB,1); $t=[math]::Round($_.Size/1GB,1)
        $pct=if($_.Size-gt0){[math]::Round($_.FreeSpace/$_.Size*100,0)}else{0}
        Row "$($_.DeviceID)" "$f GB free / $t GB  ($pct%)  $(Nz $_.FileSystem)"
        if ($pct -lt 10) { Add-Finding 'Medium' 'Storage' "Drive $($_.DeviceID) almost full" "$pct% free" 'Free up storage space.' -Confidence 'High' }
        $diskStorageList.Add([ordered]@{drive=$_.DeviceID;free_gb=$f;total_gb=$t;free_pct=$pct;fs=Nz $_.FileSystem})
    }
    # Populate sysInfo storage
    $i = 0
    foreach ($disk in $diskDrives) {
        $model    = (Nz $disk.Model).Trim()
        $iface    = Nz $disk.InterfaceType
        $diskType = if ($iface -match 'PCI|NVMe' -or $model -match 'NVMe') { 'NVMe' }
                    elseif ($model -match 'SSD') { 'SSD' }
                    else { 'HDD' }
        $lDisk    = if ($i -lt $diskStorageList.Count) { $diskStorageList[$i] } else { $null }
        $script:sysInfo.storage.Add([ordered]@{
            model    = $model
            size_gb  = [math]::Round($disk.Size/1GB,0)
            type     = $diskType
            iface    = $iface
            free_pct = if ($lDisk) { $lDisk.free_pct } else { $null }
        })
        $i++
    }
} catch { Err "Storage: $($_.Exception.Message)" }

Sub 'Virtual Memory / Pagefile'
try {
    $pf = Get-CimInstance Win32_PageFileUsage -EA 0
    if ($pf) {
        foreach ($p in $pf) {
            Row "Pagefile $($p.Name)" "CurrentUsage:$(Nz $p.CurrentUsage)MB  Peak:$(Nz $p.PeakUsage)MB  Alloc:$(Nz $p.AllocatedBaseSize)MB"
        }
    } else { Note 'No active pagefile found (disabled or automatic).' }
    $pfCfg = Get-CimInstance Win32_PageFileSetting -EA 0
    foreach ($pc in $pfCfg) { Row "Pagefile cfg" "$(Nz $pc.Name)  Init:$(Nz $pc.InitialSize)MB  Max:$(Nz $pc.MaximumSize)MB" }
} catch {}

Sub 'Security: Antivirus (WMI SecurityCenter2)'
try {
    $avList = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -EA Stop
    if ($avList) {
        foreach ($av in $avList) {
            $avEnabled  = ($av.productState -band 0x1000) -ne 0
            $avUpToDate = ($av.productState -band 0x0010) -eq 0
            Row "AV: $(Nz $av.displayName)" "Enabled:$avEnabled  UpToDate:$avUpToDate  (StateHex:0x$('{0:X6}' -f $av.productState))"
            if ($avList.Count -gt 1) { Add-Finding 'Medium' 'Security' 'Multiple AV products detected' ($avList | ForEach-Object { $_.displayName } | Join-String ', ') 'Multiple AV products can conflict and cause performance issues. Keep only one.' -Confidence 'Medium' }
        }
        $script:sysInfo.security.antivirus = @($avList | ForEach-Object { Nz $_.displayName })
    } else { Note 'No AV product registered in SecurityCenter2.' }
} catch { Note "SecurityCenter2 unavailable: $($_.Exception.Message)"; Add-Limitation 'AV detection via SecurityCenter2 failed' }

Sub 'SYSTEMINFO (Raw)'
try { (& cmd.exe /d /c 'systeminfo' 2>&1) | ForEach-Object { W "  $_" } } catch {}
FlushBuf

Sec 'B01' 'GAMING PERFORMANCE REGISTRY' 'Priority, MMCSS, HAGS, GameDVR, VRR, Timer'
Prog '[B01] Gaming Registry...'

Sub 'Win32PrioritySeparation'
try {
    $prio = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -EA Stop).Win32PrioritySeparation
    $hex  = '0x{0:X2}'-f$prio
    $m    = switch($prio){2{'STANDARD'} 38{'0x26-script target'} 42{'0x2A-Gaming'} 56{'0x38-Server'} default{"Unknown($prio)"}}
    Row 'Win32PrioritySeparation' "$prio ($hex) => $m"
    if ($prio -eq 2) { Add-Finding 'Medium' 'Gaming' 'Win32PrioritySeparation is at Windows default' "Value=$prio" 'Set to 0x26 (38) or 0x2A (42).' }
} catch { Err "PriorityControl: $($_.Exception.Message)" }

Sub 'Memory Management'
try {
    $mm = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -EA Stop
    Row 'DisablePagingExecutive'  "$(Nz $mm.DisablePagingExecutive)  (Target:1)"
    Row 'ClearPageFileAtShutdown' "$(Nz $mm.ClearPageFileAtShutdown)  (Target:0)"
    Row 'LargeSystemCache'        "$(Nz $mm.LargeSystemCache)  (Target:0)"
    Row 'PagingFiles'             (Nz $mm.PagingFiles)
    if ($mm.DisablePagingExecutive -ne 1) { Add-Finding 'Low' 'Gaming' 'DisablePagingExecutive not set' "Value=$(Nz $mm.DisablePagingExecutive)" 'Set to 1 (keep kernel in RAM).' }
} catch { Err "Memory: $($_.Exception.Message)" }

Sub 'MMCSS'
try {
    $mmcss = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -EA Stop
    Row 'NetworkThrottlingIndex' "$(Nz $mmcss.NetworkThrottlingIndex)  (FFFFFFFF=gaming target)"
    Row 'SystemResponsiveness'   "$(Nz $mmcss.SystemResponsiveness)  (0=gaming, default=20)"
    $gk='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
    if (Test-Path $gk) {
        $g = Get-ItemProperty $gk -EA 0
        Row 'Games\GPU Priority'  "$(Nz $g.'GPU Priority')  (Target:8)"
        Row 'Games\Priority'      "$(Nz $g.Priority)  (Target:6)"
        Row 'Games\Sched.Cat.'    (Nz $g.'Scheduling Category')
    } else { Add-Finding 'Medium' 'Gaming' 'MMCSS Tasks\Games key missing' $gk 'MMCSS is not optimized for gaming.' }
} catch { Err "MMCSS: $($_.Exception.Message)" }

Sub 'HAGS + GameDVR + VRR'
try {
    $gfx  = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -EA 0
    $hags = Nz $gfx.HwSchMode '?'
    $hagsStr = switch($hags){'1'{'DISABLED'} '2'{'ENABLED'} default{"Unknown($hags)"}}
    Row 'HAGS (HwSchMode)' "$hags => $hagsStr  (Target RTX 4060Ti: 2)"
    if ($hags -ne '2') { Add-Finding 'Medium' 'Display' 'HAGS disabled' "HwSchMode=$hags" 'HKLM\...\GraphicsDrivers -> HwSchMode = 2.' -Confidence 'High' }
    $gcfg = Get-ItemProperty 'HKCU:\System\GameConfigStore' -EA 0
    $gb   = Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR' -EA 0
    Row 'GameDVR_Enabled'     "$(Nz $gcfg.GameDVR_Enabled)  (Target:0)"
    Row 'AppCaptureEnabled'   "$(Nz $gb.AppCaptureEnabled)  (Target:0)"
    Row 'AllowTearing'        (Nz $gcfg.AllowTearing)
    Row 'WakeToRun (GameDVR)' (Nz $gcfg.GameDVR_DSEBehavior)
    $gfx.PSObject.Properties | Where-Object { $_.Name -match 'Sync|VRR|Adapt' -and $_.Name -notmatch '^PS' } | ForEach-Object { Row "GFX: $($_.Name)" (Nz $_.Value) }
} catch {}

Sub 'Game Mode'
try {
    $gbar = Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\GameBar' -EA 0
    $autoGM = Nz $gbar.AllowAutoGameMode '?'
    $manGM  = Nz $gbar.AutoGameModeEnabled '?'
    Row 'AllowAutoGameMode'  "$autoGM  (1=allow Windows to auto-enable)"
    Row 'AutoGameModeEnabled' "$manGM  (1=user manually enabled)"
    $gmVal = if ($autoGM -eq '1' -or $manGM -eq '1') { 'ENABLED' } else { 'DISABLED/Unknown' }
    Row 'Game Mode status'   $gmVal
} catch {}

Sub 'MPO / DWM Stutter fixes (registry)'
# MPO (Multiplane Overlay) can cause stuttering on some NVIDIA GPUs -- check if disabled
try {
    $mpoPath = 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm'
    $mpo = Get-ItemProperty $mpoPath -EA 0
    Row 'OverlayTestMode'     "$(Nz $mpo.OverlayTestMode)  (5=MPO disabled, workaround for stutter on some GPUs)"
    Row 'ForceEffectiveDisplayRefreshRate' (Nz $mpo.ForceEffectiveDisplayRefreshRate)
} catch {}
# TDR (Timeout Detection Recovery) -- very low TdrDelay can cause false GPU resets
try {
    $tdr = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -EA 0
    Row 'TdrDelay'        "$(Nz $tdr.TdrDelay)  (default=2s; very low values may cause false GPU resets)"
    Row 'TdrDdiDelay'     "$(Nz $tdr.TdrDdiDelay)"
    if ($tdr.TdrDelay -and [int]$tdr.TdrDelay -lt 2) { Add-Finding 'Medium' 'Display' 'TdrDelay is very low -- may cause false GPU reset errors' "TdrDelay=$($tdr.TdrDelay)s" 'Increase TdrDelay to 8 or higher if getting TDR crashes with a healthy GPU.' -Confidence 'Medium' }
} catch {}

Sub 'FSE + Fullscreen Optimizations'
try {
    $fso = Get-ItemProperty 'HKCU:\System\GameConfigStore' -EA 0
    Row 'FSEBehaviorMode'     (Nz $fso.GameDVR_FSEBehaviorMode)
    Row 'HonorUserFSEBehav.'  (Nz $fso.GameDVR_HonorUserFSEBehaviorMode)
} catch {}
FlushBuf

Sec 'B02' 'TIMER RESOLUTION / MSI INTERRUPT / BCD' 'Latency-critical system settings'
Prog '[B02] Timer + MSI...'

Sub 'BCD entries'
(bcdedit /enum 2>&1) | ForEach-Object { W "  $_" }

Sub 'GPU MSI Interrupt Mode'
try {
    Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\PCI' -EA 0 | Where-Object { $_.PSChildName -match 'VEN_10DE' } | ForEach-Object {
        Get-ChildItem $_.PSPath -EA 0 | ForEach-Object {
            $dp = "$($_.PSPath)\Device Parameters\Interrupt Management"
            if (Test-Path $dp) {
                $msiP = "$dp\MessageSignaledInterruptProperties"
                $afP  = "$dp\Affinity Policy"
                if (Test-Path $msiP) {
                    $msi = Get-ItemProperty $msiP -EA 0
                    Row 'GPU MSISupported'     "$(Nz $msi.MSISupported)  (1=enabled, recommended)"
                    Row 'GPU MsgNumLimit'      (Nz $msi.MessageNumberLimit)
                    if ($msi.MSISupported -ne 1) { Add-Finding 'Low' 'GPU' 'GPU MSI interrupt mode disabled' '' 'Set MSISupported=1 for lower latency.' }
                }
                if (Test-Path $afP) {
                    $af = Get-ItemProperty $afP -EA 0
                    Row 'GPU DevicePriority'   (Nz $af.DevicePriority)
                    Row 'GPU AffinityOverride'  (Nz $af.AssignmentSetOverride)
                }
            }
        }
    }
} catch {}
FlushBuf

Sec 'C01' 'DISPLAY: EDID + WMI MONITOR CLASSES' 'EDID, all modes, WMI monitor classes'
Prog '[C01] Display + EDID...'

Sub 'WmiMonitorID'
try {
    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorID -EA Stop | ForEach-Object {
        $nameBytes = [byte[]]($_.UserFriendlyName | Where-Object { $_ -ne 0 })
        $mfrBytes  = [byte[]]($_.ManufacturerName | Where-Object { $_ -ne 0 })
        $serBytes  = [byte[]]($_.SerialNumberID   | Where-Object { $_ -ne 0 })
        $name = if ($nameBytes.Count -gt 0) { [System.Text.Encoding]::ASCII.GetString($nameBytes).Trim() } else { '' }
        $mfr  = if ($mfrBytes.Count  -gt 0) { [System.Text.Encoding]::ASCII.GetString($mfrBytes).Trim()  } else { '' }
        $ser  = if ($serBytes.Count  -gt 0) { [System.Text.Encoding]::ASCII.GetString($serBytes).Trim()  } else { '' }
        Row 'Monitor Name'     $name
        Row 'Manufacturer'       $mfr
        Row 'Serial'           $ser
        Row 'WeekOfManuf.'     (Nz $_.WeekOfManufacture)
        Row 'YearOfManuf.'     (Nz $_.YearOfManufacture)
        W ''
    }
} catch { Note "WmiMonitorID: $($_.Exception.Message)" }

Sub 'WmiMonitorBasicDisplayParams'
try {
    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams -EA Stop | ForEach-Object {
        Row 'MaxHImageSize' "$(Nz $_.MaxHorizontalImageSize) cm"
        Row 'MaxVImageSize' "$(Nz $_.MaxVerticalImageSize) cm"
        Row 'VideoInputType' (Nz $_.VideoInputType)
        Row 'DisplayTransferCharacteristic' (Nz $_.DisplayTransferCharacteristic)
        W ''
    }
} catch {}

Sub 'WmiMonitorConnectionParams'
try {
    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorConnectionParams -EA Stop | ForEach-Object {
        $ct = switch($_.VideoOutputTechnology){-2147483648{'Internal'} 0{'VGA'} 4{'DVI'} 5{'HDMI'} 6{'LVDS'} 10{'DP'} 11{'Embedded DP'} default{"Type:$($_.VideoOutputTechnology)"}}
        Row 'Connection type' $ct
        W ''
    }
} catch {}

Sub 'WmiMonitorListedSupportedSourceModes (all driver modes)'
try {
    $modes = Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorListedSupportedSourceModes -EA Stop
    foreach ($mon in $modes) {
        W "  Monitor: $(Nz $mon.InstanceName)"
        $preferredIdx = Nz $mon.PreferredMonitorSourceModeIndex
        $i = 0
        foreach ($mode in $mon.MonitorSourceModes) {
            $pref = if ($i -eq $preferredIdx) { ' [PREFERRED]' } else { '' }
            $ar   = Get-AR ([int](Nz $mode.HorizontalActivePixels 0)) ([int](Nz $mode.VerticalActivePixels 0))
            W ("    [{0,3}]{1} {2}x{3}  @{4}Hz  {5}" -f $i, $pref, (Nz $mode.HorizontalActivePixels), (Nz $mode.VerticalActivePixels), (Nz $mode.VSyncFreqNumerator), $ar)
            $i++
        }
        W ''
    }
} catch { Note "WmiMonitorSupportedModes: $($_.Exception.Message)" }

Sub 'EDID from registry (HKLM\...\Enum\DISPLAY)'
$dispEnum = 'HKLM:\SYSTEM\CurrentControlSet\Enum\DISPLAY'
if (Test-Path $dispEnum) {
    Get-ChildItem $dispEnum -EA 0 | ForEach-Object {
        $model = $_.PSChildName
        Get-ChildItem $_.PSPath -EA 0 | ForEach-Object {
            Div
            Row 'Instance'  $_.PSChildName
            Row 'Description'  (Nz $_.GetValue('DeviceDesc'))
            $edidPath = "$($_.PSPath)\Device Parameters"
            if (Test-Path $edidPath) {
                $rawEDID = (Get-ItemProperty $edidPath -EA 0).EDID
                if ($rawEDID -and $rawEDID.Length -ge 128) {
                    $p = Parse-EDID $rawEDID
                    if ($p -and -not $p.Error) {
                        Row 'EDID manufacturer'  "$($p.Mfr)  Prod:$($p.Prod)  $($p.Year)/W$($p.Week)"
                        Row 'EDID Name'        (Nz $p.Name)
                        Row 'EDID Serial'      (Nz $p.Serial)
                        Row 'Input'          "$($p.VI)  $($p.BD)  Digital:$($p.Digital)"
                        Row 'Physical'         "$($p.hCm)x$($p.vCm) cm  =>  $($p.DiagIn) inches"
                        Row 'Gamma'            "$($p.Gamma)"
                        Row 'Vertical freq.'       "$(Nz $p.MinV)-$(Nz $p.MaxV) Hz"
                        Row 'Horizontal freq.'      "$(Nz $p.MinH)-$(Nz $p.MaxH) kHz"
                        Row 'Max pixel clock'    "$(Nz $p.MaxPix) MHz"
                        if ($p.StdT) { Row 'Default Timings' ($p.StdT -join '  ') }
                        $di=0
                        foreach ($dt in $p.DetT) {
                            $di++; $pref=if($di-eq1){' [NATIVE]'}else{''}
                            W "  Timing$di$pref $($dt.hA)x$($dt.vA) @$($dt.RR)Hz  Pix:$($dt.PixMHz)MHz  ($(Get-AR $dt.hA $dt.vA))"
                            W "    H: Act=$($dt.hA) FP=$($dt.hFP) SW=$($dt.hSW) Bl=$($dt.hBl) Tot=$($dt.hT)"
                            W "    V: Act=$($dt.vA) FP=$($dt.vFP) SW=$($dt.vSW) Bl=$($dt.vBl) Tot=$($dt.vT)"
                            W "    Phys: $($dt.hMM)x$($dt.vMM)mm  Interlaced:$($dt.Int)"
                        }
                        $ov = (Get-ItemProperty $edidPath -EA 0).EDID_OVERRIDE
                        if ($ov -and $ov.Length -ge 128) {
                            $p2 = Parse-EDID $ov
                            if ($p2 -and -not $p2.Error) {
                                W "  CRU OVERRIDE: $(Nz $p2.Name)  MaxV:$(Nz $p2.MaxV)Hz"
                                foreach ($dt2 in $p2.DetT) { W "    Override: $($dt2.hA)x$($dt2.vA) @$($dt2.RR)Hz  Pix:$($dt2.PixMHz)MHz" }
                            }
                        }
                    } else { Note "EDID error: $(Nz $p.Error)" }
                } else { Note 'No EDID found (monitor may be disconnected)' }
            }
            W ''
        }
    }
}
FlushBuf

Sec 'C02' 'VIDEO ADAPTER REGISTRY + GRAPHICSDRIVERS SUBKEYS' 'DefaultSettings, Scaling, Configuration, ScaleFactors, MonitorDataStore'
Prog '[C02] Video Adapter + GraphicsDrivers...'

Sub 'GraphicsDrivers - all relevant subkeys'
$gfxSubPaths = @(
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers',
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Scheduler',
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Configuration',
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Connectivity',
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\ScaleFactors',
    'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\MonitorDataStore'
)
foreach ($gp in $gfxSubPaths) {
    if (-not (Test-Path $gp)) { continue }
    W "  Path: $gp"
    try {
        (Get-ItemProperty $gp -EA Stop).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
            Row "  $($_.Name)" (Nz $_.Value)
        }
    } catch {}
    Get-ChildItem $gp -EA 0 | Select-Object -First 5 | ForEach-Object {
        W "    SubKey: $($_.PSChildName)"
        (Get-ItemProperty $_.PSPath -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
            Row "      $($_.Name)" (Nz $_.Value)
        }
    }
    W ''
}

Sub 'Video-Adapter DefaultSettings (per display)'
$videoRoot = 'HKLM:\SYSTEM\CurrentControlSet\Control\Video'
if (Test-Path $videoRoot) {
    Get-ChildItem $videoRoot -EA 0 | ForEach-Object {
        $guid = $_.PSChildName
        Get-ChildItem $_.PSPath -EA 0 | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
            $v = Get-ItemProperty $_.PSPath -EA 0
            $xr = Nz $v.'DefaultSettings.XResolution'; $yr = Nz $v.'DefaultSettings.YResolution'
            if (-not $xr) { return }
            W "  {$guid} / Display $($_.PSChildName):"
            Row '  Resolution' "$xr x $yr  ($(Get-AR ([int]$xr) ([int]$yr)))"
            Row '  Refresh'    "$(Nz $v.'DefaultSettings.VRefresh') Hz"
            Row '  BitsPerPel' (Nz $v.'DefaultSettings.BitsPerPel')
            Row '  Scaling'    (Nz $v.Scaling)
            Row '  NV_Modes'   (Nz $v.NV_Modes)
            $v.PSObject.Properties | Where-Object { $_.Name -match 'Refresh|Scale|Color|Gamma|HDR|Mode|Custom|Timing|Freq|VSync|Tearing' -and $_.Name -notmatch '^PS|DefaultSettings' } | ForEach-Object {
                Row "  $($_.Name)" (Nz $_.Value)
            }
        }
    }
}

Sub 'Vendor registry (NVIDIA/AMD/Intel Toplevel)'
foreach ($vp in @('HKLM:\SOFTWARE\NVIDIA Corporation','HKLM:\SOFTWARE\WOW6432Node\NVIDIA Corporation','HKLM:\SOFTWARE\AMD','HKLM:\SOFTWARE\Intel')) {
    if (-not (Test-Path $vp)) { continue }
    W "  $vp"
    Get-ChildItem $vp -EA 0 | Select-Object -First 10 | ForEach-Object { W "    $($_.PSChildName)" }
}
FlushBuf

Sec 'C03' 'DPI / SCALING / COLOR / DWM' 'All display-relevant HKCU/HKLM keys'
Prog '[C03] DPI + color...'

$dispRegKeys = @(
    @{K='HKCU:\Control Panel\Desktop';              L='Control Panel Desktop'}
    @{K='HKCU:\Control Panel\Desktop\WindowMetrics'; L='WindowMetrics'}
    @{K='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Scaling'; L='Explorer Scaling'}
    @{K='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DisplaySettings'; L='Explorer DisplaySettings'}
    @{K='HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\VideoSettings'; L='VideoSettings (HDR)'}
    @{K='HKCU:\SOFTWARE\Microsoft\Avalon.Graphics'; L='Avalon.Graphics (WPF DPI)'}
    @{K='HKCU:\SOFTWARE\Microsoft\Windows\DWM';     L='DWM HKCU'}
    @{K='HKLM:\SOFTWARE\Microsoft\Windows\DWM';     L='DWM HKLM'}
    @{K='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ICM'; L='ICM/WCS'}
    @{K='HKCU:\Control Panel\Desktop\PerMonitorSettings'; L='Per-Monitor DPI'}
    @{K='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\FontDPI'; L='FontDPI'}
)
foreach ($dk in $dispRegKeys) {
    if (-not (Test-Path $dk.K)) { continue }
    Sub $dk.L
    try {
        (Get-ItemProperty $dk.K -EA Stop).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
            Row $_.Name (Nz $_.Value)
        }
    } catch {}
    if ($dk.K -match 'PerMonitorSettings') {
        Get-ChildItem $dk.K -EA 0 | ForEach-Object {
            W "  Monitor: $($_.PSChildName)"
            (Get-ItemProperty $_.PSPath -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row "    $($_.Name)" (Nz $_.Value) }
        }
    }
}

Sub 'ICC color profiles (assignments + files)'
$iccReg = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ICM\ProfileAssociations'
if (Test-Path $iccReg) {
    Get-ChildItem $iccReg -EA 0 | ForEach-Object {
        W "  Monitor: $($_.PSChildName)"
        (Get-ItemProperty $_.PSPath -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row "    $($_.Name)" (Nz $_.Value) }
    }
}
$iccDir = Join-Path $env:WINDIR 'System32\spool\drivers\color'
if (Test-Path $iccDir) {
    Sub 'Installed ICC/ICM files'
    Get-ChildItem $iccDir -File -EA 0 | Sort-Object LastWriteTime -Descending | ForEach-Object {
        W ("  {0,-45} {1,-12} {2}" -f $_.Name, ($_.Length/1KB -as [int]).ToString()+'KB', $_.LastWriteTime.ToString('yyyy-MM-dd'))
    }
}
FlushBuf

Sec 'D01' 'INPUT: MOUSE / KEYBOARD / HID' 'Polling, settings, class registry'
Prog '[D01] Input...'

Sub 'Mouse Control Panel'
try {
    $mouse = Get-ItemProperty 'HKCU:\Control Panel\Mouse' -EA 0
    $mouse.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row $_.Name (Nz $_.Value) }
    if ($mouse.MouseSpeed -ne 0 -or $mouse.MouseThreshold1 -ne 0 -or $mouse.MouseThreshold2 -ne 0) {
        Add-Finding 'Medium' 'Input' 'Enhance Pointer Precision / mouse acceleration may be enabled' "Speed=$(Nz $mouse.MouseSpeed) T1=$(Nz $mouse.MouseThreshold1) T2=$(Nz $mouse.MouseThreshold2)" 'For gaming: MouseSpeed=0, Threshold1=0, Threshold2=0 (acceleration off).'
    }
} catch {}

Sub 'mouclass / mouhid Parameters'
foreach ($sp in @('HKLM:\SYSTEM\CurrentControlSet\Services\mouclass\Parameters','HKLM:\SYSTEM\CurrentControlSet\Services\mouhid\Parameters')) {
    if (-not (Test-Path $sp)) { continue }
    W "  $sp"
    (Get-ItemProperty $sp -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row "  $($_.Name)" (Nz $_.Value) }
}

Sub 'WMI Pointing + Keyboard'
Get-CimInstance Win32_PointingDevice -EA 0 | ForEach-Object {
    Row 'Mouse'          "$($_.Name)  |  Buttons:$(Nz $_.NumberOfButtons)  |  SampleRate:$(Nz $_.SampleRate)Hz"
}
Get-CimInstance Win32_Keyboard -EA 0 | ForEach-Object {
    Row 'Keyboard'      "$($_.Name)  |  Keys:$(Nz $_.NumberOfKeys)  |  Layout:$(Nz $_.Layout)"
}

Sub 'Keyboard layout + repeat'
try {
    $kb = Get-ItemProperty 'HKCU:\Control Panel\Keyboard' -EA 0
    $kb.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row $_.Name (Nz $_.Value) }
    $kl = Get-ItemProperty 'HKCU:\Keyboard Layout\Preload' -EA 0
    $kl.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { Row "Layout $_" (Nz $_.Value) }
} catch {}
FlushBuf

Sec 'D02' 'AUDIO DEVICES + ENDPOINTS' 'Render, Capture, WASAPI, Default'
Prog '[D02] Audio...'
try {
    $audBase = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio'
    foreach ($dir in @('Render','Capture')) {
        Sub "$dir Devices"
        $dp = Join-Path $audBase $dir
        if (-not (Test-Path $dp)) { continue }
        Get-ChildItem $dp -EA 0 | ForEach-Object {
            $st = switch($_.GetValue('DeviceState')){1{'ACTIVE'} 2{'DISABLED'} 4{'N/V'} 8{'UNPLUGGED'} default{"?"}}
            $pp = Join-Path $_.PSPath 'Properties'
            $fname = ''
            if (Test-Path $pp) {
                $props = Get-ItemProperty $pp -EA 0
                if ($props) { $fname = Nz ($props.PSObject.Properties | Where-Object { $_.Name -match ',14$' } | Select-Object -First 1 -ExpandProperty Value) }
            }
            Row $st (Nz $fname 'Unknown')
        }
    }
    Sub 'WMI SoundDevice'
    Get-CimInstance Win32_SoundDevice -EA 0 | ForEach-Object {
        $sName = Nz $_.Name ; $sStat = Nz $_.Status
        Row 'Sound' "$sName  |  $sStat"
    }
} catch { Err "Audio: $($_.Exception.Message)" }
FlushBuf

Sec 'E01' 'REGISTRY: DUPLICATES' 'Uninstall (name+publisher+version), Run keys, fonts'
Prog '[E01] Duplicates...'

Sub 'Uninstall duplicates (name+publisher+version)'
try {
    $allInst = @()
    foreach ($up in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')) {
        if (-not (Test-Path $up)) { continue }
        Get-ChildItem $up -EA 0 | ForEach-Object {
            $n=$_.GetValue('DisplayName'); if(-not $n){return}
            if ($_.GetValue('SystemComponent') -eq 1) { return }
            $v=$_.GetValue('DisplayVersion'); $pub=$_.GetValue('Publisher')
            $allInst += [PSCustomObject]@{Name=$n;Ver=$v;Pub=$pub;GUID=$_.PSChildName;Path=$up}
        }
    }
    $dupes = $allInst | Group-Object { ($_.Name + '|' + $_.Pub + '|' + $_.Ver).ToLower() } | Where-Object { $_.Count -gt 1 }
    if ($dupes) {
        foreach ($d in $dupes) {
            $g0Name  = $d.Group[0].Name
            $g0Ver   = $d.Group[0].Ver
            $gCount  = $d.Group.Count
            W "  DUPLICATE: $g0Name  v$g0Ver"
            $d.Group | ForEach-Object { W "    $($_.GUID)  in  $($_.Path)" }
            Add-Finding 'Low' 'Registry' "Duplicate uninstall entry: $g0Name" "$g0Ver ($gCount entries)" 'Check whether this is an x86/x64 pair or a real duplicate entry.'
        }
    } else { Note 'No duplicates found.' }
} catch { Err "Uninstall duplicates: $($_.Exception.Message)" }

Sub 'Run keys - HKLM+HKCU conflicts'
try {
    $hklmRun=@{}; $hkcuRun=@{}
    (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -EA 0).PSObject.Properties | Where-Object {$_.Name -notmatch '^PS'} | ForEach-Object { $hklmRun[$_.Name]=$_.Value }
    (Get-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'  -EA 0).PSObject.Properties | Where-Object {$_.Name -notmatch '^PS'} | ForEach-Object { $hkcuRun[$_.Name]=$_.Value }
    $overlap = $hklmRun.Keys | Where-Object { $hkcuRun.ContainsKey($_) }
    if ($overlap) {
        foreach ($k in $overlap) {
            W "  CONFLICT: [$k]"
            Row '  HKLM' (Nz $hklmRun[$k])
            Row '  HKCU' (Nz $hkcuRun[$k])
            Add-Finding 'Low' 'Registry' "Run-key conflict: [$k]" "HKLM vs HKCU" 'Check which entry is intended.'
        }
    } else { Note 'No Run-key conflicts.' }
} catch {}

Sub 'Font duplicates'
try {
    $fk = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts' -EA 0
    $ff=@{}
    $fk.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
        $file=(Nz $_.Value).ToLower()
        if (-not $ff.ContainsKey($file)) { $ff[$file]=@() }
        $ff[$file]+=$_.Name
    }
    $dupF = $ff.GetEnumerator() | Where-Object { $_.Value.Count -gt 1 }
    if ($dupF) { foreach ($df in $dupF) { W "  DUPLICATE font file: $($df.Key)" ; $df.Value | ForEach-Object { W "    -> $_" } } }
    else { Note 'No font duplicates.' }
} catch {}
FlushBuf

Sec 'E02' 'REGISTRY: ORPHANED ENTRIES' 'Run, ShellExt, ContextMenu, MUI, AppCompat, Fonts, SharedDLL'
Prog '[E02] Orphans...'

$sysKW = @('system32','syswow64','windowsapps','\\windows\\','msiexec','svchost','cmd.exe /c','\\microsoft\\')
function Is-Sys { param([string]$c) ; $cl=$c.ToLower() ; foreach($k in $sysKW){if($cl-match[regex]::Escape($k)){return $true}} ; return $false }

Sub 'Startup Run keys (EXE missing)'
ProgSub 'Checking Run keys for missing EXEs...'
$orphRun=0
foreach ($rk in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce')) {
    if (-not (Test-Path $rk)) { continue }
    (Get-ItemProperty $rk -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
        $cmd=Nz $_.Value
        if ($cmd -match '^\{' -or (Is-Sys $cmd)) { return }
        $exe=Resolve-Exe $cmd
        if ($exe -and -not (Test-ExeExists $exe)) {
            W "  [ORPHAN] [$($_.Name)] in $rk" ; W "    => $cmd" ; $orphRun++
            Add-Finding 'Medium' 'Registry' "Startup entry EXE missing: $($_.Name)" $cmd 'Review the entry and remove it if appropriate.'
        }
    }
}
Note "Orphaned Run entries: $orphRun"

Sub 'Shell Extensions Approved (DLL missing)'
ProgSub 'Checking Shell Extensions for missing DLLs...'
$orphSE=0
$se = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved' -EA 0
if ($se) {
    $se.PSObject.Properties | Where-Object { $_.Name -match '^\{' } | ForEach-Object {
        $cl=$_.Name; $desc=Nz $_.Value; $ok=$false
        foreach ($cp in @("HKLM:\SOFTWARE\Classes\CLSID\$cl\InProcServer32","Registry::HKEY_CLASSES_ROOT\CLSID\$cl\InProcServer32")) {
            if (Test-Path $cp) {
                $dll=Nz (Get-RegDefaultValue $cp)
                if ($dll -and (Test-Path (Resolve-Dll $dll) -EA 0)) { $ok=$true; break }
            }
        }
        if (-not $ok) { W "  [ORPHAN] $cl | $desc" ; $orphSE++; Add-Finding 'Medium' 'Registry' "Shell Extension DLL missing: $desc" $cl 'Can cause Explorer instability.' }
    }
}
Note "Orphaned ShellExt: $orphSE"

Sub 'Context Menu Handler (DLL missing => right-click lag!)'
ProgSub 'Checking Context Menu Handlers (*, Directory, Drive, Folder)...'
$orphCMH=0
foreach ($root in @('*','Directory','Directory\Background','Drive','Folder')) {
    $p="Registry::HKEY_CLASSES_ROOT\$root\shellex\ContextMenuHandlers"
    if (-not (Test-Path $p)) { continue }
    Get-ChildItem $p -EA 0 | ForEach-Object {
        $hn=$_.PSChildName; $cl=Nz $_.GetValue('')
        if (-not ($cl -match '^\{')) { $cl=if($hn -match '^\{'){$hn}else{return} }
        $ok=$false
        foreach ($cp in @("HKLM:\SOFTWARE\Classes\CLSID\$cl\InProcServer32","Registry::HKEY_CLASSES_ROOT\CLSID\$cl\InProcServer32")) {
            if (Test-Path $cp) {
                $dll=Nz (Get-RegDefaultValue $cp)
                if ($dll -and (Test-Path (Resolve-Dll $dll) -EA 0)) { $ok=$true; break }
            }
        }
        if (-not $ok) { W "  [ORPHAN] [$root] $hn | $cl" ; $orphCMH++; Add-Finding 'High' 'Registry' "ContextMenu Handler DLL missing (=> right-click lag)" "$root\$hn | $cl" 'Remove this CLSID entry from HKCR.' }
    }
}
Note "Orphaned ContextMenu Handlers: $orphCMH  (=> right-click delay!)"

Sub 'AppCompatFlags (EXE missing)'
$orphAC=0
foreach ($ap in @('HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers','HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers')) {
    if (-not (Test-Path $ap)) { continue }
    (Get-ItemProperty $ap -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' -and $_.Name -match '^[A-Za-z]:\\' } | ForEach-Object {
        if (-not (Test-Path $_.Name -EA 0)) { W "  [ORPHAN] $($_.Name) => $(Nz $_.Value)" ; $orphAC++ }
    }
}
Note "Orphaned AppCompatFlags: $orphAC"

Sub 'MUI Cache (EXE missing)'
$muiP='HKCU:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache'
$orphMUI=0; $seen=@{}; $muiChecked=0; $muiTotal=0
if (Test-Path $muiP) {
    $muiProps = (Get-ItemProperty $muiP -EA 0).PSObject.Properties | Where-Object { $_.Name -match '\.FriendlyAppName$' }
    $muiTotal = @($muiProps).Count
    ProgSub "MUI Cache: $muiTotal entries found, checking..."
    $muiStart = Get-Date
    $muiTimeout = 60
    foreach ($prop in $muiProps) {
        if (((Get-Date)-$muiStart).TotalSeconds -gt $muiTimeout) {
            Note "MUI Cache: Timeout after $muiTimeout seconds. $muiChecked of $muiTotal checked."
            break
        }
        $exe = $prop.Name -replace '\.FriendlyAppName$',''
        if ($seen[$exe]) { continue } ; $seen[$exe]=$true
        $muiChecked++
        if ($muiChecked % 25 -eq 0) {
            $muiElapsed = [math]::Round(((Get-Date)-$muiStart).TotalSeconds,1)
            Write-Host ("    -> MUI: {0}/{1} checked  ({2}s)  orphans so far: {3}" -f $muiChecked, $muiTotal, $muiElapsed, $orphMUI) -ForegroundColor DarkCyan
        }
        if (-not (Test-Path $exe -EA 0)) { W "  [ORPHAN] $exe" ; $orphMUI++ }
    }
}
Note "Orphaned MUI-Cache: $orphMUI  (checked: $muiChecked/$muiTotal)"

Sub 'SharedDLLs (file missing)'
ProgSub 'Checking SharedDLLs for missing files...'
$orphSD=0
if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SharedDLLs') {
    (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\SharedDLLs' -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' -and $_.Name -match '^[A-Za-z]:\\' } | ForEach-Object {
        if (-not (Test-Path $_.Name -EA 0)) { $sdFile = $_.Name ; $sdCnt = Nz $_.Value ; W "  [ORPHAN] Count=$sdCnt | $sdFile" ; $orphSD++ }
    }
}
Note "Missing SharedDLLs: $orphSD"

Sub 'Font entries (file missing)'
$orphFont = 0; $fd1 = Join-Path $env:SystemRoot 'Fonts'; $fd2 = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts' } else { '' }
(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts' -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
    $file=Nz $_.Value; if(-not $file){return}
    $abs=if($file-match'^[A-Za-z]:\\'){$file}else{Join-Path $fd1 $file}
    if (-not (Test-Path $abs -EA 0) -and ($fd2 -eq '' -or -not (Test-Path (Join-Path $fd2 $file) -EA 0))) { W "  [ORPHAN] $($_.Name) => $file" ; $orphFont++ }
}
Note "Missing font entries: $orphFont"
FlushBuf

Sec 'F01' 'SCHEDULED TASKS: CATEGORIZED' 'Display, PnP, input, audio, telemetry, WakeToRun, high-frequency, old tasks'
Prog '[F01] Loading tasks...'
$allTasks = @(Get-ScheduledTask -EA 0)
ProgSub "Loaded: $($allTasks.Count) tasks. Categorizing..."

$kwDisp  = @('display','monitor','screen','resolution','scaling','dpi','hdr','color','colour','gamma','icc','calibrat','brightness','refresh','fullscreen','directx','dx','dwm','desktop.?window','render','visual','contrast','overdrive','vsync','tearing','gsync','freesync','vrr','graphics','gpu')
$kwPnP   = @('plug.?play','pnp','device.?detect','hardware','driver.?install','device.?install')
$kwInput = @('input','keyboard','mouse','hid','touch','pen','stylus','gamepad','joystick','controller','pointer','cursor','tablet','trackpad')
$kwAudio = @('audio','sound','speaker','headphone','headset','microphone','midi','playback','recording','endpoint','audioservice')
$kwBTUSB = @('bluetooth','bth','usb','wlan','wifi','wireless')
$kwTelem = @('telemetry','ceip','feedback','watson','consolidator','usb.?ceip','sqm','siuf','diagnosis','datacollect','compatibility.?appraiser','programdata.?updater','aitag')
$kwXbox  = @('xbox','xbl')

$specialPaths = @{
    '\Microsoft\Windows\Display\'                      = 'Display'
    '\Microsoft\Windows\DirectX\'                      = 'Display'
    '\Microsoft\Windows\WindowsColorSystem\'           = 'Display'
    '\Microsoft\Windows\DWM\'                          = 'Display'
    '\Microsoft\Windows\Plug and Play\'                = 'PnP'
    '\Microsoft\Windows\Device Information\'           = 'PnP'
    '\Microsoft\Windows\Input\'                        = 'Input'
    '\Microsoft\Windows\TabletPC\'                     = 'Input'
    '\Microsoft\Windows\AudioSrv\'                     = 'Audio'
    '\Microsoft\Windows\Bluetooth\'                    = 'BT_USB'
    '\Microsoft\Windows\USB\'                          = 'BT_USB'
    '\Microsoft\Windows\Customer Experience Improvement Program\' = 'Telemetry'
    '\Microsoft\Windows\Feedback\'                     = 'Telemetry'
    '\Microsoft\Windows\Feedback\Siuf\'                = 'Telemetry'
    '\Microsoft\Windows\NetTrace\'                     = 'Telemetry'
    '\Microsoft\Windows\PI\'                           = 'Telemetry'
    '\Microsoft\Windows\Diagnosis\'                    = 'Telemetry'
    '\Microsoft\Windows\Windows Error Reporting\'      = 'Telemetry'
    '\Microsoft\Windows\RetailDemo\'                   = 'Unnecessary'
    '\Microsoft\Windows\Maps\'                         = 'Unnecessary'
    '\Microsoft\XblGameSave\'                          = 'Xbox'
}

$cats = @{
    Display   = [System.Collections.Generic.List[object]]::new()
    PnP       = [System.Collections.Generic.List[object]]::new()
    Input     = [System.Collections.Generic.List[object]]::new()
    Audio     = [System.Collections.Generic.List[object]]::new()
    BT_USB    = [System.Collections.Generic.List[object]]::new()
    Telemetry= [System.Collections.Generic.List[object]]::new()
    Xbox      = [System.Collections.Generic.List[object]]::new()
    Unnecessary  = [System.Collections.Generic.List[object]]::new()
    Broken    = [System.Collections.Generic.List[object]]::new()
    WakeToRun = [System.Collections.Generic.List[object]]::new()
    HighFreq  = [System.Collections.Generic.List[object]]::new()
    AltTask   = [System.Collections.Generic.List[object]]::new()
}

$oldDate = (Get-Date).AddDays(-180)

foreach ($task in $allTasks) {
    $fn    = "$(Nz $task.TaskPath)$(Nz $task.TaskName)"
    $fnLow = $fn.ToLower()
    $desc  = (Nz $task.Description).ToLower()
    $auth  = (Nz $task.Author).ToLower()
    $exe   = ''
    foreach ($action in $task.Actions) {
        if ($action.CimClass.CimClassName -match 'ExecAction') { $exe=(Nz $action.Execute).ToLower(); break }
    }

    if ($exe -match '^[a-z]:\\' -and -not (Test-Path $exe -EA 0)) {
        $cats.Broken.Add([PSCustomObject]@{Task=$task;Reason='EXE missing'})
    }

    if ($task.Settings -and $task.Settings.WakeToRun -eq $true) {
        $cats.WakeToRun.Add([PSCustomObject]@{Task=$task;Reason='WakeToRun=True'})
        Add-Finding 'Low' 'Scheduler' "WakeToRun Task: $fn" '' 'Can wake the PC from sleep.'
    }

    foreach ($trig in $task.Triggers) {
        if ($trig.Repetition -and $trig.Repetition.Interval) {
            $iv = Nz $trig.Repetition.Interval
            $mins = 999
            if ($iv -match 'PT(\d+)S')  { $mins=[int]$matches[1]/60 }
            elseif ($iv -match 'PT(\d+)M') { $mins=[int]$matches[1] }
            elseif ($iv -match 'PT(\d+)H') { $mins=[int]$matches[1]*60 }
            if ($mins -lt 15) { $cats.HighFreq.Add([PSCustomObject]@{Task=$task;Reason="Repeat:$iv"}); break }
        }
    }

    $info = Get-ScheduledTaskInfo -InputObject $task -EA 0
    if ($info -and $info.LastRunTime -and $info.LastRunTime.Year -gt 2000 -and $info.LastRunTime -lt $oldDate -and $task.State -ne 'Disabled') {
        $cats.AltTask.Add([PSCustomObject]@{Task=$task;Reason="LastRun:$($info.LastRunTime.ToString('yyyy-MM-dd'))"})
    }

    $matched=$false
    foreach ($sp in $specialPaths.Keys) {
        if ($task.TaskPath -eq $sp) { $cats[$specialPaths[$sp]].Add([PSCustomObject]@{Task=$task;Reason="Path:$sp"}); $matched=$true; break }
    }
    if ($matched) { continue }

    $kwMap = @{Display=$kwDisp; PnP=$kwPnP; Input=$kwInput; Audio=$kwAudio; BT_USB=$kwBTUSB; Telemetry=$kwTelem; Xbox=$kwXbox}
    foreach ($cat in $kwMap.Keys) {
        $found=$false
        foreach ($kw in $kwMap[$cat]) {
            if ($fnLow -match $kw -or $desc -match $kw -or $exe -match $kw -or $auth -match $kw) {
                $cats[$cat].Add([PSCustomObject]@{Task=$task;Reason="KW:$kw"}); $found=$true; break
            }
        }
        if ($found) { break }
    }
}

$catOrder = @('Broken','WakeToRun','HighFreq','AltTask','Telemetry','Xbox','Unnecessary','Display','PnP','Input','Audio','BT_USB')
$catLabel = @{Broken='BROKEN TASKS (EXE missing)';WakeToRun='WAKE-TO-RUN (wakes PC from sleep)';HighFreq='HIGH FREQUENCY (<15 min interval)';AltTask='OLD TASKS (>180 days since last run)';Telemetry='TELEMETRY TASKS';Xbox='XBOX TASKS';Unnecessary='UNNEEDED TASKS';Display='DISPLAY/SCALING/COLOR';PnP='PLUG AND PLAY';Input='INPUT DEVICES';Audio='AUDIO/OUTPUT';BT_USB='BLUETOOTH/USB'}

Sub 'SUMMARY'
W "  Total: $($allTasks.Count) Tasks"
foreach ($cat in $catOrder) { W ("  {0,-45} {1,4}" -f $catLabel[$cat], $cats[$cat].Count) }

foreach ($cat in $catOrder) {
    if ($cats[$cat].Count -eq 0) { continue }
    Sub $catLabel[$cat]
    foreach ($e in ($cats[$cat] | Sort-Object { $_.Task.State })) { Print-Task $e.Task $e.Reason }
}
FlushBuf

Sec 'F02' 'ALL SCHEDULED TASKS - COMPLETE' 'All uncategorized tasks with full details'
Prog '[F02] All remaining tasks...'
$listed = [System.Collections.Generic.HashSet[string]]::new()
foreach ($cat in $catOrder) { foreach ($e in $cats[$cat]) { $listed.Add("$(Nz $e.Task.TaskPath)$(Nz $e.Task.TaskName)") | Out-Null } }

$remaining = $allTasks | Where-Object { -not $listed.Contains("$(Nz $_.TaskPath)$(Nz $_.TaskName)") } | Sort-Object TaskPath, TaskName
Note "Categorized: $($listed.Count)  |  Uncategorized: $($remaining.Count)"
foreach ($task in $remaining) { Print-Task $task 'Uncategorized' }
FlushBuf

Sec 'G01' 'DRIVERS: DRIVERQUERY + PNPUTIL' 'All drivers, OEM packages, display/monitor classes'
Prog '[G01] Driver...'

Sub 'driverquery /v'
ProgSub 'driverquery /v - can take 30-60 seconds...'
try { (& cmd.exe /d /c 'driverquery /v /fo list' 2>&1) | ForEach-Object { W "  $_" } } catch { Err "driverquery: $($_.Exception.Message)" }

Sub 'pnputil /enum-drivers'
ProgSub 'pnputil /enum-drivers...'
try { (& cmd.exe /d /c 'pnputil /enum-drivers' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'pnputil /enum-devices /class Display'
try { (& cmd.exe /d /c 'pnputil /enum-devices /class Display' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'pnputil /enum-devices /class Monitor'
try { (& cmd.exe /d /c 'pnputil /enum-devices /class Monitor' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'sc query - all kernel drivers'
try { (& cmd.exe /d /c 'sc query type= driver state= all' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'Win32_PnPSignedDriver -- Age + Provider Analysis'
ProgSub 'Win32_PnPSignedDriver - WMI query (can be slow)...'
try {
    $cutoffOld  = (Get-Date).AddYears(-2)
    $keyClasses = @('Display','Net','Media','SCSIAdapter','HDC','System','Bluetooth','HIDClass','USB')
    $msPatterns = @('^Microsoft','^Windows','^Standard ','USBSTOR','Root Enumerator')
    Get-CimInstance Win32_PnPSignedDriver -EA Stop | Where-Object { $_.DeviceName } | Sort-Object DeviceName | ForEach-Object {
        $drvDate  = try { [datetime]$_.DriverDate } catch { $null }
        $ageStr   = if ($drvDate) { "$(Format-DateValue $_.DriverDate 'yyyy-MM-dd')" } else { 'date?' }
        $vendor   = Nz $_.Manufacturer
        $isMsInbox= $msPatterns | Where-Object { $vendor -match $_ } | Select-Object -First 1
        $provider = if ($isMsInbox) { '[MS-inbox]' } else { '[Vendor]  ' }
        $isKey    = $keyClasses | Where-Object { $_.DeviceClass -match $_ } | Select-Object -First 1
        $ageFlag  = if ($drvDate -and $drvDate -lt $cutoffOld -and -not $isMsInbox) { ' [OLD!]' } else { '' }
        Row (Nz $_.DeviceName) "$provider  v$(Nz $_.DriverVersion)  $ageStr$ageFlag  $vendor  $(Nz $_.InfName)"
        if ($ageFlag -and $_.DeviceClass -match 'Display|Net|Media|SCSIAdapter') {
            Add-Finding 'Low' 'Driver' "Key driver over 2 years old: $(Nz $_.DeviceName)" "Date: $ageStr  Class: $(Nz $_.DeviceClass)" 'Check manufacturer site for updated driver.' -Confidence 'Medium'
        }
    }
} catch { Err "Win32_PnPSignedDriver: $($_.Exception.Message)"; Add-Limitation 'Win32_PnPSignedDriver WMI query failed' }

Sub 'Win32_SystemDriver (Kernel Drivers)'
try {
    Get-CimInstance Win32_SystemDriver -EA Stop | Sort-Object Name | ForEach-Object {
        Row (Nz $_.Name) "$(Nz $_.State) | $(Nz $_.StartMode) | $(Nz $_.PathName)"
    }
} catch {}

Sub 'PnP devices (HID/audio/Bluetooth/USB/display)'
try {
    Get-CimInstance Win32_PnPEntity -EA 0 | Where-Object {
        $_.PNPClass -match 'HIDClass|AudioEndpoint|Bluetooth|USB|Display|Monitor' -and $_.Status -ne 'Unknown'
    } | Sort-Object PNPClass, Name | ForEach-Object {
        Row (Nz $_.PNPClass 'N/A') "$(Nz $_.Name)  |  $(Nz $_.Status)  |  $(Nz $_.DeviceID)"
    }
} catch {}

Sub 'Win32_USBControllerDevice'
try {
    Get-CimInstance Win32_USBControllerDevice -EA Stop | ForEach-Object {
        $dep = (Nz $_.Dependent) -replace '.*DeviceID="(.+)".*','$1'
        Row 'USB device' $dep
    }
} catch {}
FlushBuf

Sec 'G02' 'GAMING-RELEVANT SERVICES' 'Status + StartType of all relevant services'
Prog '[G02] Services...'
$svcs = [ordered]@{
    'SysMain'='Superfetch (gaming: manual)'; 'DiagTrack'='Telemetry (can be disabled)'; 'WSearch'='Search index (gaming: manual)'
    'XblGameSave'='Xbox game save'; 'XboxNetApiSvc'='Xbox networking API'; 'bthserv'='Bluetooth'
    'wuauserv'='Windows Update'; 'CloudflareWARP'='WARP VPN'; 'vgc'='Vanguard Client'; 'vgk'='Vanguard Kernel'
    'NvTelemetryContainer'='NVIDIA telemetry'; 'NVDisplay.ContainerLocalSystem'='NVIDIA Display Container'
    'nvagent'='NVIDIA Network'; 'ProcessLasso'='ProcessLasso'; 'BitsrvService'='Bitsum Service'
    'Audiosrv'='Audio (must be running)'; 'AudioEndpointBuilder'='Audio endpoint (must be running)'
    'RzActionSvc'='Razer Action'; 'SteelSeriesTrayServer'='SteelSeries Tray'
}
foreach ($s in $svcs.Keys) {
    $svc = Get-Service $s -EA 0
    if ($svc) {
        Row $s "$($svc.Status) | $($svc.StartType) | $($svcs[$s])"
        if ($s -eq 'SysMain' -and $svc.Status -eq 'Running' -and $svc.StartType -eq 'Automatic') {
            Add-Finding 'Low' 'Services' 'SysMain (Superfetch) runs automatically' '' 'Set to Manual for gaming.'
        }
    } else { Row $s "N/A | $($svcs[$s])" }
}
FlushBuf

Sec 'H01' 'POWER PLAN + WAKE DIAGNOSTICS' 'All powercfg options including wake diagnostics'
Prog '[H01] Power...'

Sub 'Active power plan'
try {
    $activePlan = (& cmd.exe /d /c 'powercfg /getactivescheme' 2>&1) -join ' '
    W "  $activePlan"
    $script:sysInfo.power_plan = $activePlan.Trim()
    if ($activePlan -match 'Balanced') {
        Add-Finding 'Low' 'Power' 'Balanced power plan active' $activePlan 'Switch to High Performance or Ultimate Performance for gaming.' -Confidence 'High'
    }
} catch {}

Sub 'Fast Startup'
try {
    $fsKey = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -EA 0).HiberbootEnabled
    $fsStr = switch ($fsKey) { 1 { 'ENABLED' } 0 { 'DISABLED' } default { 'Unknown' } }
    Row 'HiberbootEnabled (Fast Startup)' "$fsStr  (Disable for troubleshooting; can prevent full hardware re-init)"
} catch {}

Sub 'USB Selective Suspend'
try {
    $usbSuspend = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\USB\Parameters' -EA 0).DisableSelectiveSuspend
    $usbStr = if ($usbSuspend -eq 1) { 'DISABLED (good for gaming peripherals)' } else { 'ENABLED (default; can cause input device stutters)' }
    Row 'USB Selective Suspend' $usbStr
} catch {}

Sub 'PCIe Link State Power Management'
try {
    # Check if ASPM is off in the active scheme (recommended for gaming)
    $aspmOut = (& cmd.exe /d /c 'powercfg /Q SCHEME_CURRENT SUB_PCIEXPRESS ASPM' 2>&1) -join "`n"
    W "  $aspmOut"
} catch {}

$powerCmds = [ordered]@{
    'All plans'      = 'powercfg /L'
    'Sleep States'   = 'powercfg /A'
    'Wake devices'   = 'powercfg /DEVICEQUERY wake_armed'
    'Power Requests' = 'powercfg /REQUESTS'
    'Last wake'      = 'powercfg /LASTWAKE'
    'Full Query'     = 'powercfg /Q'
}
foreach ($name in $powerCmds.Keys) {
    Sub $name
    try { (& cmd.exe /d /c $powerCmds[$name] 2>&1) | ForEach-Object { W "  $_" } } catch {}
}
FlushBuf

Sec 'H02' 'TCP/IP + NETWORK' 'Gaming latency, adapters, Wi-Fi, TCP global settings'
Prog '[H02] Network...'

Sub 'TCP/IP Parameters'
try {
    $tcp = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -EA 0
    Row 'TcpAckFrequency'  "$(Nz $tcp.TcpAckFrequency)  (1=immediate, gaming)"
    Row 'TCPNoDelay'       "$(Nz $tcp.TCPNoDelay)  (1=no Nagle)"
    Row 'TcpDelAckTicks'   (Nz $tcp.TcpDelAckTicks)
    Row 'DefaultTTL'       (Nz $tcp.DefaultTTL)
    if ($tcp.TcpAckFrequency -ne 1) { Add-Finding 'Low' 'Network' 'TcpAckFrequency != 1' "Value=$(Nz $tcp.TcpAckFrequency)" 'Set to 1 for gaming (immediate ACK).' }
} catch {}

Sub 'netsh int tcp show global'
try { (& cmd.exe /d /c 'netsh int tcp show global' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'WLAN Interface'
try { (& cmd.exe /d /c 'netsh wlan show interfaces' 2>&1) | ForEach-Object { W "  $_" } } catch {}

Sub 'ipconfig /all'
try { (& cmd.exe /d /c 'ipconfig /all' 2>&1) | ForEach-Object { W "  $_" } } catch {}
FlushBuf

Sec 'I01' 'EVENT LOGS: DISPLAY / GPU / WHEA / CRASHES' "Last $EventDays days, filtered to relevant providers"
Prog '[I01] Event Logs...'
$evtStart = (Get-Date).AddDays(-[int]$EventDays)

Sub 'System + Application: Critical/Error/Warning'
ProgSub "Reading event logs (System + Application, last $EventDays days)..."
foreach ($log in @('System','Application')) {
    try {
        $evts = Get-WinEvent -FilterHashtable @{LogName=$log; StartTime=$evtStart; Level=1,2,3} -EA Stop
        Note "${log}: $($evts.Count) entries (Critical/Error/Warning last $EventDays days)"
        $evts | Select-Object -First 100 | ForEach-Object {
            W ("  [{0}] [{1}] {2} | {3}" -f $_.TimeCreated.ToString('yyyy-MM-dd HH:mm'), $_.LevelDisplayName, (Nz $_.ProviderName), (ShortText $_.Message 200))
        }
    } catch { Note "$log EventLog: $($_.Exception.Message)" }
}

Sub 'GPU/Display/WHEA/Storage/BugCheck providers (filtered)'
$providers = @(
    'nvlddmkm','amdkmdag','amdwddmg','igfx',          # GPU drivers
    'dxgkrnl','Microsoft-Windows-DWM-Core',             # DirectX / DWM
    'Kernel-PnP','WHEA-Logger',                         # hardware errors
    'Microsoft-Windows-Kernel-Power',                   # unexpected shutdowns (Event 41)
    'Microsoft-Windows-Kernel-General',                 # BugCheck / BSOD
    'Microsoft-Windows-BugCheck',                       # BSOD
    'disk','volmgr','Ntfs','stornvme','storahci',       # storage errors
    'Microsoft-Windows-Display'                         # display driver events
)
foreach ($prov in $providers) {
    foreach ($log in @('System','Application')) {
        try {
            $evts = Get-WinEvent -FilterHashtable @{LogName=$log; ProviderName=$prov; StartTime=$evtStart; Level=1,2,3} -MaxEvents 50 -EA Stop
            if ($evts.Count -gt 0) {
                W "  Provider: $prov ($log) - $($evts.Count) entries"
                $evts | ForEach-Object {
                    $msg = ShortText $_.Message 200
                    W ("    [{0}] {1} | {2}" -f $_.TimeCreated.ToString('yyyy-MM-dd HH:mm'), $_.LevelDisplayName, $msg)
                    if ($prov -match 'nvlddmkm|dxgkrnl|WHEA') {
                        Add-Finding 'High' 'EventLog' "GPU/WHEA hardware error: $prov" $msg 'Check for GPU driver crash or hardware fault.' -Confidence 'High'
                    }
                    if ($prov -match 'Kernel-Power' -and $_.Id -eq 41) {
                        Add-Finding 'High' 'EventLog' 'Kernel-Power Event 41: Unexpected shutdown (possible crash/BSOD/power loss)' $msg 'Check for overheating, PSU issues, or BSOD. Correlate with minidumps.' -Confidence 'High'
                        $script:sysInfo.recent_changes.crashes += [ordered]@{time=$_.TimeCreated.ToString('yyyy-MM-ddTHH:mm:ss');type='KernelPower41';msg=ShortText $_.Message 100}
                    }
                    if ($prov -match 'BugCheck|Kernel-General' -and $_.Message -match 'bug.?check') {
                        Add-Finding 'High' 'EventLog' 'BugCheck (BSOD) recorded in event log' $msg 'Analyse minidump with WinDbg for root cause.' -Confidence 'High'
                    }
                    if ($prov -match '^disk$|^volmgr$|^Ntfs$') {
                        Add-Finding 'Medium' 'Storage' "Disk/filesystem error: $prov" $msg 'Run CHKDSK /f /r on the affected drive.' -Confidence 'Medium'
                    }
                }
            }
        } catch {}
    }
}

Sub 'Reliability Records (Win32_ReliabilityRecords)'
try {
    $rel = Get-CimInstance -Namespace root\cimv2 -ClassName Win32_ReliabilityRecords -EA Stop | Where-Object { $_.EventIdentifier -ne 1 } | Sort-Object TimeGenerated -Descending | Select-Object -First 50
    $rel | ForEach-Object {
        W ("  [{0}] [{1}] {2} | {3}" -f (Format-DateValue $_.TimeGenerated 'yyyy-MM-dd'), (Nz $_.RecordType), (Nz $_.SourceName), (ShortText $_.Message 300))
    }
} catch { Note "Reliability Records: $($_.Exception.Message)" }

Sub 'WER ReportArchive (crash index)'
$werPath = Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportArchive'
if (Test-Path $werPath) {
    Get-ChildItem $werPath -Directory -EA 0 | Sort-Object LastWriteTime -Descending | ForEach-Object {
        Row $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') $_.Name
    }
} else { Note 'WER ReportArchive not found.' }

Sub 'Windows minidumps'
$mdPath = Join-Path $env:WINDIR 'Minidump'
if (Test-Path $mdPath) {
    Get-ChildItem $mdPath -File -EA 0 | Sort-Object LastWriteTime -Descending | ForEach-Object {
        Row $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') "$($_.Name)  $([math]::Round($_.Length/1KB,0)) KB"
        Add-Finding 'Medium' 'Crash' "Minidump found: $($_.Name)" $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm') 'Analyze crash dump with WinDbg.' -Confidence 'High'
        $script:sysInfo.recent_changes.crashes += [ordered]@{time=$_.LastWriteTime.ToString('yyyy-MM-ddTHH:mm:ss');type='Minidump';file=$_.Name}
    }
} else { Note 'No minidumps.' }
FlushBuf

Sec 'I02' 'RECENT CHANGES TIMELINE' "Windows Updates, driver installs, app installs -- last $EventDays days"
Prog '[I02] Recent changes...'
$changeStart = (Get-Date).AddDays(-[int]$EventDays)

# Collect all events into a flat list and sort chronologically
$timeline = [System.Collections.Generic.List[object]]::new()

Sub 'Windows Update history'
ProgSub 'Querying Windows Update history...'
try {
    $wuSession  = New-Object -ComObject Microsoft.Update.Session -EA Stop
    $wuSearcher = $wuSession.CreateUpdateSearcher()
    $wuCount    = $wuSearcher.GetTotalHistoryCount()
    if ($wuCount -gt 0) {
        $wuHistory = $wuSearcher.QueryHistory(0, [math]::Min($wuCount, 200))
        $wuFiltered= $wuHistory | Where-Object { $_.Date -gt $changeStart }
        Note "Windows Update: $wuCount total history entries, $(@($wuFiltered).Count) in last $EventDays days"
        foreach ($u in ($wuFiltered | Sort-Object Date -Descending)) {
            $status = switch ($u.ResultCode) { 2{'OK'} 3{'Succ.'} 4{'FAILED'} 5{'ABORTED'} default{"Code:$($u.ResultCode)"} }
            $title  = ShortText $u.Title 120
            W ("  [{0}] [{1}] {2}" -f $u.Date.ToString('yyyy-MM-dd HH:mm'), $status, $title)
            $timeline.Add([PSCustomObject]@{Time=$u.Date;Type='WindowsUpdate';Status=$status;Detail=$title})
            if ($u.ResultCode -eq 4) { Add-Finding 'Medium' 'Update' "Failed Windows Update: $title" "Date: $($u.Date.ToString('yyyy-MM-dd'))" 'Retry the update or check Windows Update troubleshooter.' -Confidence 'High' }
        }
        $script:sysInfo.recent_changes.updates = @($wuFiltered | Sort-Object Date -Descending | Select-Object -First 30 | ForEach-Object {
            [ordered]@{time=$_.Date.ToString('yyyy-MM-ddTHH:mm:ss');status=($_.ResultCode);title=ShortText $_.Title 100}
        })
    } else { Note 'No Windows Update history found.' }
} catch { Note "Windows Update history COM failed: $($_.Exception.Message)"; Add-Limitation 'Windows Update history unavailable (COM error)' }

Sub 'Recent driver installs (Setup event log)'
ProgSub 'Checking SetupAPI / Microsoft-Windows-DriverFrameworks-UserMode...'
try {
    $drvEvts = Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-DriverFrameworks-UserMode';StartTime=$changeStart} -MaxEvents 100 -EA Stop
    $drvEvts | Where-Object { $_.Id -in @(10000,10001,10100) } | ForEach-Object {
        $msg = ShortText $_.Message 120
        W ("  [{0}] Id:{1} {2}" -f $_.TimeCreated.ToString('yyyy-MM-dd HH:mm'), $_.Id, $msg)
        $timeline.Add([PSCustomObject]@{Time=$_.TimeCreated;Type='DriverInstall';Status='Info';Detail=$msg})
        $script:sysInfo.recent_changes.driver_changes += [ordered]@{time=$_.TimeCreated.ToString('yyyy-MM-ddTHH:mm:ss');detail=ShortText $msg 80}
    }
} catch { Note 'Driver install log (UserMode driver framework) not accessible.' }

Sub 'Recent app installs (registry / event log)'
ProgSub 'Checking recent installations from MsiInstaller event log...'
try {
    $msiEvts = Get-WinEvent -FilterHashtable @{LogName='Application';ProviderName='MsiInstaller';StartTime=$changeStart;Id=@(1033,1034,11707,11708)} -MaxEvents 80 -EA Stop
    $msiEvts | ForEach-Object {
        $msg = ShortText $_.Message 120
        W ("  [{0}] Id:{1} {2}" -f $_.TimeCreated.ToString('yyyy-MM-dd HH:mm'), $_.Id, $msg)
        $timeline.Add([PSCustomObject]@{Time=$_.TimeCreated;Type='AppInstall';Status='Info';Detail=$msg})
    }
} catch { Note 'MSI install log not accessible or empty.' }

Sub 'Combined chronological timeline'
if ($timeline.Count -gt 0) {
    W "  Total events in timeline: $($timeline.Count)"
    $timeline | Sort-Object Time -Descending | ForEach-Object {
        W ("  [{0}] {1,-15} {2}" -f $_.Time.ToString('yyyy-MM-dd HH:mm'), "[$($_.Type)]", $_.Detail)
    }
} else { Note 'No timeline events collected.' }
FlushBuf

Sec 'K01' 'STORAGE JUNK ANALYSIS' 'Temp, Update-Cache, Prefetch, WinSxS, Browser-Cache'
Prog '[K01] Storage Junk...'

if ($SkipStorageScan) {
    Note "Storage junk scan skipped (-SkipStorageScan). Add -StorageScanTimeout [seconds] to adjust per-folder timeout (default: $StorageScanTimeout s)."
} else {

function Get-FolderSizeMB {
    param([string]$path, [int]$TimeoutSec = $StorageScanTimeout)
    if (-not (Test-Path $path)) { return [PSCustomObject]@{PathExists=$false; SizeMB=0; FileCount=0; TimedOut=$false} }
    try {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $totalSize = [long]0; $count = 0; $timedOut = $false
        # Pipeline streaming: ForEach-Object checks time each item so we can bail on huge folders
        # (return inside ForEach-Object acts as 'continue'; after $timedOut is set we just skip)
        Get-ChildItem $path -Recurse -File -Force -EA 0 | ForEach-Object {
            if ($timedOut) { return }
            if ($sw.Elapsed.TotalSeconds -gt $TimeoutSec) { $timedOut = $true; return }
            $totalSize += $_.Length; $count++
        }
        return [PSCustomObject]@{PathExists=$true; SizeMB=[math]::Round($totalSize/1MB,1); FileCount=$count; TimedOut=$timedOut}
    } catch {
        return [PSCustomObject]@{PathExists=$true; SizeMB=-1; FileCount=-1; TimedOut=$false}
    }
}

$junkLocations = [ordered]@{
    'User Temp (%TEMP%)'                      = $env:TEMP
    'System Temp (%SystemRoot%\Temp)'         = (Join-Path $env:SystemRoot 'Temp')
    'Windows Update Cache (SoftwareDistrib.)' = (Join-Path $env:SystemRoot 'SoftwareDistribution\Download')
    'Prefetch'                                = (Join-Path $env:SystemRoot 'Prefetch')
    'WinSxS (component store)'            = (Join-Path $env:SystemRoot 'WinSxS')
    'Windows.old (previous Windows installation)'       = (Join-Path $env:SystemDrive 'Windows.old')
    'WER LocalReports'                        = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WER\ReportArchive')
    'WER QueueReports'                        = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WER\ReportQueue')
    'Windows Logs'                            = (Join-Path $env:SystemRoot 'Logs')
    'CBS Logs'                                = (Join-Path $env:SystemRoot 'Logs\CBS')
    'Thumbnail Cache'                         = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer')
    'IIS Logs'                                = (Join-Path $env:SystemDrive 'inetpub\logs')
    'Crash Dumps (Users)'                     = (Join-Path $env:LOCALAPPDATA 'CrashDumps')
    'Crash Dumps (System)'                    = (Join-Path $env:SystemRoot 'Minidump')
}

$totalJunkMB = 0
foreach ($label in $junkLocations.Keys) {
    $path = $junkLocations[$label]
    ProgSub "Measuring: $label"
    $r = Get-FolderSizeMB $path
    if ($r.PathExists) {
        if ($r.TimedOut) {
            Row "[TIMEOUT] $label" ">${$r.SizeMB} MB  (${$r.FileCount}+ files, cut at ${StorageScanTimeout}s)  |  $path"
            Note "Folder scan timed out after ${StorageScanTimeout}s. Use -StorageScanTimeout [seconds] to increase, or -SkipStorageScan to skip."
        } else {
            $sev = if ($r.SizeMB -gt 5000) { '[!!LARGE]' } elseif ($r.SizeMB -gt 1000) { '[LARGE]' } else { '[OK]   ' }
            Row "$sev $label" "$($r.SizeMB) MB  ($($r.FileCount) files)  |  $path"
            $totalJunkMB += $r.SizeMB
            if ($r.SizeMB -gt 5000) {
                Add-Finding 'Medium' 'Storage' "Large junk folder: $label" "$($r.SizeMB) MB" 'Consider cleanup (Disk Cleanup / manual).'
            }
        }
    } else {
        Row "[N/A]   $label" $path
    }
}
Row 'TOTAL measured' "$([math]::Round($totalJunkMB,0)) MB"

Sub 'Largest files in User-TEMP (Top 20)'
ProgSub 'Measuring user TEMP folder recursively...'
if (Test-Path $env:TEMP) {
    Get-ChildItem $env:TEMP -Recurse -File -Force -EA 0 |
        Sort-Object Length -Descending |
        Select-Object -First 20 |
        ForEach-Object {
            Row "$([math]::Round($_.Length/1MB,1)) MB" $_.FullName
        }
}

Sub 'Largest files in System-TEMP (Top 20)'
$sysTmp = Join-Path $env:SystemRoot 'Temp'
if (Test-Path $sysTmp) {
    Get-ChildItem $sysTmp -Recurse -File -Force -EA 0 |
        Sort-Object Length -Descending |
        Select-Object -First 20 |
        ForEach-Object {
            Row "$([math]::Round($_.Length/1MB,1)) MB" $_.FullName
        }
}

Sub 'Browser caches (estimated size)'
$browserCaches = [ordered]@{
    'Chrome Cache'  = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Cache')
    'Edge Cache'    = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Cache')
    'Firefox Cache' = (Join-Path $env:LOCALAPPDATA 'Mozilla\Firefox\Profiles')
    'Opera Cache'   = (Join-Path $env:APPDATA 'Opera Software\Opera Stable\Cache')
    'Brave Cache'   = (Join-Path $env:LOCALAPPDATA 'BraveSoftware\Brave-Browser\User Data\Default\Cache')
}
foreach ($b in $browserCaches.Keys) {
    $path = $browserCaches[$b]
    if (Test-Path $path) {
        $r = Get-FolderSizeMB $path
        Row $b "$($r.SizeMB) MB  |  $path"
        if ($r.SizeMB -gt 2000) { Add-Finding 'Low' 'Storage' "Large browser cache: $b" "$($r.SizeMB) MB" 'Clear browser cache.' }
    }
}

Sub 'WinSxS analysis (DISM)'
ProgSub 'DISM /AnalyzeComponentStore - can take 1-2 minutes...'
try {
    (& cmd.exe /d /c 'dism /Online /Cleanup-Image /AnalyzeComponentStore' 2>&1) | ForEach-Object { W "  $_" }
} catch { Note 'DISM not available.' }

}  # end if (-not $SkipStorageScan)
FlushBuf

Sec 'K02' 'NETWORK ADAPTER OFFLOADS + ADVANCED PROPERTIES' 'Interrupt Moderation, LSO, RSS, Checksum Offloads - Gaming-relevant'
Prog '[K02] Network Offloads...'

$gamingOffloadKW = @(
    'InterruptModeration',
    'LsoV2IPv4',
    'LsoV2IPv6',
    'ReceiveSideScaling',
    'TCPChecksumOffloadIPv4',
    'TCPChecksumOffloadIPv6',
    'UDPChecksumOffloadIPv4',
    'UDPChecksumOffloadIPv6',
    'JumboPacket',
    'FlowControl',
    'SpeedDuplex',
    'ReceiveBuffers',
    'TransmitBuffers',
    'NumRssQueues',
    'RssBaseProcNumber',
    'MaxRssProcessors',
    'PriorityVLANTag',
    'NetworkDirect',
    'RDMA',
    'EEE',
    'AutoPowerSaveModeEnabled',
    'WakeOnMagicPacket',
    'WakeOnPattern',
    'PMARPOffload',
    'PMNSOffload'
)

Sub 'Get-NetAdapterAdvancedProperty (all adapters)'
try {
    $adapters = Get-NetAdapter -EA Stop
    foreach ($adapter in $adapters) {
        Div
        Row 'Adapter'       "$($adapter.Name)  |  $($adapter.InterfaceDescription)"
        Row 'Status'        "$($adapter.Status)  |  $($adapter.LinkSpeed)"
        Row 'MAC'           $adapter.MacAddress
        try {
            $props = Get-NetAdapterAdvancedProperty -Name $adapter.Name -EA Stop
            foreach ($prop in ($props | Sort-Object DisplayName)) {
                $isGaming = $false
                foreach ($kw in $gamingOffloadKW) {
                    if ($prop.RegistryKeyword -match $kw -or $prop.DisplayName -match ($kw -replace '([A-Z])',' $1').Trim()) {
                        $isGaming = $true; break
                    }
                }
                $flag = if ($isGaming) { '[GAMING]' } else { '       ' }
                Row "$flag $($prop.DisplayName)" "$($prop.DisplayValue)  [Valid: $($prop.ValidDisplayValues -join ', ')]"

                if ($prop.RegistryKeyword -match 'EEE|AutoPowerSave' -and -not (Test-NetAdapterPropertyDisabled $prop)) {
                    Add-Finding 'Medium' 'Network' "Energy Efficient Ethernet enabled: $($adapter.Name)" "$($prop.DisplayName)=$($prop.DisplayValue)" 'Disable EEE for low gaming latency (adapter properties -> Disabled).'
                }
                if ($prop.RegistryKeyword -match 'InterruptModeration' -and (Test-NetAdapterPropertyEnabled $prop)) {
                    Add-Finding 'Low' 'Network' "Interrupt Moderation enabled: $($adapter.Name)" "$($prop.DisplayName)=$($prop.DisplayValue)" 'For lowest latency: disable Interrupt Moderation (slightly increases CPU load).'
                }
                if ($prop.RegistryKeyword -match 'LsoV2' -and (Test-NetAdapterPropertyEnabled $prop)) {
                    Add-Finding 'Low' 'Network' "Large Send Offload enabled: $($adapter.Name)" "$($prop.DisplayName)=$($prop.DisplayValue)" 'LSO can cause latency spikes in gaming traffic. Test by disabling it and measuring ping.'
                }
                if ($prop.RegistryKeyword -match 'FlowControl' -and -not (Test-NetAdapterPropertyDisabled $prop)) {
                    Add-Finding 'Low' 'Network' "Flow Control enabled: $($adapter.Name)" "$($prop.DisplayName)=$($prop.DisplayValue)" 'Flow Control can cause latency spikes. For gaming: disable it.'
                }
            }
        } catch { Note "No advanced properties for $($adapter.Name): $($_.Exception.Message)" }
        W ''
    }
} catch { Err "Get-NetAdapter: $($_.Exception.Message)" }

Sub 'Network adapter registry (HKLM\...\Control\Class\{4D36E96E})'
$netClassPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4D36E96E-E325-11CE-BFC1-08002BE10318}'
if (Test-Path $netClassPath) {
    $ci = Get-ItemProperty $netClassPath -EA 0
    Row 'UpperFilters' (Nz ($ci.UpperFilters -join ', '))
    Row 'LowerFilters' (Nz ($ci.LowerFilters -join ', '))
    Get-ChildItem $netClassPath -EA 0 | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
        $d = Get-ItemProperty $_.PSPath -EA 0
        $dn = Nz $d.DriverDesc
        if (-not $dn) { return }
        W "  Adapter: [$($_.PSChildName)] $dn"
        $d.PSObject.Properties | Where-Object {
            $_.Name -match 'Interrupt|Offload|RSS|Jumbo|Flow|Speed|Duplex|Wake|EEE|Buffer|Queue|Power|RDMA' -and $_.Name -notmatch '^PS'
        } | ForEach-Object { Row "    $($_.Name)" (Nz $_.Value) }
    }
}

Sub 'netsh int tcp show global + heuristics'
try { (& cmd.exe /d /c 'netsh int tcp show global' 2>&1) | ForEach-Object { W "  $_" } } catch {}
try { (& cmd.exe /d /c 'netsh int tcp show heuristics' 2>&1) | ForEach-Object { W "  $_" } } catch {}
try { (& cmd.exe /d /c 'netsh int tcp show rsc' 2>&1) | ForEach-Object { W "  $_" } } catch {}
FlushBuf

Sec 'K03' 'PHYSICAL STARTUP FOLDERS' 'shell:startup, shell:common startup, LNK targets validated'
Prog '[K03] Startup folders...'

$wshell = $null
try { $wshell = New-Object -ComObject WScript.Shell -EA Stop } catch {}

$userStartup = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
$allStartup  = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp'
try {
    if ($wshell) {
        $sfUser = $wshell.SpecialFolders.Item('Startup')
        $sfAll  = $wshell.SpecialFolders.Item('AllUsersStartup')
        if (-not [string]::IsNullOrWhiteSpace($sfUser)) { $userStartup = $sfUser }
        if (-not [string]::IsNullOrWhiteSpace($sfAll))  { $allStartup  = $sfAll }
    }
} catch {}

$startupFolders = [ordered]@{
    'User Startup (shell:startup)'              = $userStartup
    'All Users Startup (shell:common startup)'  = $allStartup
}

foreach ($label in $startupFolders.Keys) {
    Sub $label
    $folder = $startupFolders[$label]
    Row 'Path' $folder
    if (-not (Test-Path $folder)) { Note 'Folder does not exist.'; continue }

    $files = Get-ChildItem $folder -File -Force -EA 0
    if (-not $files -or $files.Count -eq 0) { Note 'Folder is empty (no startup entries).'; continue }

    Note "entries: $($files.Count)"
    foreach ($file in $files) {
        Div
        Row 'File'       $file.Name
        Row 'Path'        $file.FullName
        Row 'Modified'   $file.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
        Row 'Size'     "$($file.Length) Bytes"

        if ($file.Extension -eq '.lnk' -and $wshell) {
            try {
                $shortcut  = $wshell.CreateShortcut($file.FullName)
                $target    = Nz $shortcut.TargetPath
                $args      = Nz $shortcut.Arguments
                $workDir   = Nz $shortcut.WorkingDirectory
                $targetExists = Test-Path $target -EA 0
                $statusStr = if ($targetExists) { 'OK' } else { 'TARGET MISSING!' }

                Row 'LNK target'     "$target  [$statusStr]"
                if ($args)    { Row 'LNK arguments' $args }
                if ($workDir) { Row 'LNK WorkDir'   $workDir }

                if (-not $targetExists -and $target -ne '') {
                    Add-Finding 'Medium' 'Startup' "Startup LNK target missing: $($file.Name)" $target 'Remove the orphaned startup entry from the Startup folder.'
                } else {
                    Add-Finding 'Info' 'Startup' "Startup entry (physical): $($file.Name)" $target 'Verify whether this is intended.'
                }
            } catch { Note "LNK resolution failed: $($_.Exception.Message)" }
        } elseif ($file.Extension -match '\.(bat|cmd|exe|ps1|vbs|js)') {
            $exists = Test-Path $file.FullName -EA 0
            Row 'Type'         $file.Extension
            Row 'Exists'   $exists
            Add-Finding 'Info' 'Startup' "Direct startup script: $($file.Name)" $file.FullName 'Verify whether this is intended.'
        }
        W ''
    }
}

Sub 'WMI Win32_StartupCommand (additional)'
try {
    Get-CimInstance Win32_StartupCommand -EA Stop | ForEach-Object {
        Div
        Row 'Name'      (Nz $_.Name)
        Row 'Command'   (Nz $_.Command)
        Row 'Location'  (Nz $_.Location)
        Row 'User'      (Nz $_.User)
        $exe    = Resolve-Exe (Nz $_.Command)
        $exists = Test-ExeExists (Nz $_.Command)
        Row 'EXE-Status' "$(if($exists){'OK'}else{'MISSING!'})  =>  $exe"
        if (-not $exists -and $exe -match '^[A-Za-z]:\\') {
            Add-Finding 'Medium' 'Startup' "Win32_StartupCommand EXE missing: $(Nz $_.Name)" (Nz $_.Command) 'Clean up the orphaned startup entry.'
        }
        W ''
    }
} catch { Err "Win32_StartupCommand: $($_.Exception.Message)" }

Sub 'Startup Approved keys (Task Manager enabled/disabled)'
$apKeys = @(
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder',
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder'
)
foreach ($ak in $apKeys) {
    if (-not (Test-Path $ak)) { continue }
    W "  $ak"
    (Get-ItemProperty $ak -EA 0).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
        $bytes   = $_.Value
        $enabled = if ($bytes -and $bytes.Count -ge 1 -and $bytes[0] -eq 2) { 'ACTIVE' } else { 'DISABLED (Task Manager)' }
        Row "  $($_.Name)" $enabled
    }
}
FlushBuf

Sec 'J01' 'DIRECTX DIAGNOSTICS (DXDIAG)' 'Complete DxDiag output'
Prog '[J01] Waiting for DxDiag...'
if ($SkipDxDiag) {
    Note 'DxDiag was skipped via -SkipDxDiag.'
} else {
    $dxTimeout = 60   # seconds; DxDiag on cold systems can take 30-50 s

    # If we have the process handle, wait for the process to exit (not just for the file to appear).
    # This is the only reliable signal that DxDiag has finished writing and closed the file.
    if ($script:dxProc -and -not $script:dxProc.HasExited) {
        Write-Host '  Waiting for DxDiag to finish writing...' -ForegroundColor DarkCyan
        $dxDone = $script:dxProc.WaitForExit($dxTimeout * 1000)   # WaitForExit takes milliseconds
        if (-not $dxDone) {
            Write-Host "  DxDiag did not exit within $dxTimeout s. Trying to read partial output." -ForegroundColor DarkYellow
            try { $script:dxProc.Kill() } catch {}
        }
    }

    # Fallback: if no process handle (Start-Process failed but the file showed up somehow)
    if (-not (Test-Path $dxFile)) {
        Err "DxDiag output file not found after ${dxTimeout}s."
    } else {
        $dxElapsed = if ($script:dxProc) {
            try { [math]::Round(((Get-Date) - $script:dxProc.StartTime).TotalSeconds, 1) } catch { '?' }
        } else { '?' }
        try {
            Get-Content $dxFile -Encoding Unicode -ErrorAction Stop | ForEach-Object { W "  $_" }
            Note "DxDiag read OK (elapsed: ${dxElapsed}s)"
        } catch {
            # DxDiag occasionally writes UTF-8 without BOM on some configurations
            try { Get-Content $dxFile -Encoding UTF8 -EA 0 | ForEach-Object { W "  $_" } } catch { Err "DxDiag: $($_.Exception.Message)" }
        }
    }
}
FlushBuf

Sec 'Z01' 'FINDINGS SUMMARY' 'All findings sorted by severity'
Prog '[Z01] Findings...'

$sevOrder = @('Critical','High','Medium','Low','Info')
foreach ($sev in $sevOrder) {
    $group = $script:findings | Where-Object { $_.Severity -eq $sev }
    if (-not $group -or @($group).Count -eq 0) { continue }
    Sub "[$sev] - $(@($group).Count) entries"
    foreach ($f in $group) {
        Div
        Row 'Category'       $f.Category
        Row 'Confidence'     $f.Confidence
        Row 'Title'          $f.Title
        if ($f.Evidence)     { Row 'Evidence'        $f.Evidence }
        if ($f.Recommendation){ Row 'Recommendation' $f.Recommendation }
    }
}

$elapsed = [math]::Round(((Get-Date)-$startTime).TotalSeconds,1)
W ''; W ('=' * 72)
W "  SCAN COMPLETE: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  |  Duration: $elapsed s"
W "  Findings: Critical=$(@($script:findings|Where-Object{$_.Severity-eq'Critical'}).Count)  High=$(@($script:findings|Where-Object{$_.Severity-eq'High'}).Count)  Medium=$(@($script:findings|Where-Object{$_.Severity-eq'Medium'}).Count)  Low=$(@($script:findings|Where-Object{$_.Severity-eq'Low'}).Count)"
W ('=' * 72)
FlushBuf

# ============================================================
# AI SUMMARY SECTION  (append at end -- AI should read this)
# ============================================================
Sec 'Z02' 'AI SUMMARY -- QUICK REFERENCE' 'Key facts for AI analysis -- structured plain-text snapshot'
Prog '[Z02] AI Summary...'
W ''
W '  This section contains a structured snapshot of key system facts'
W '  and all findings. AI: start here for quick orientation.'
W ''
Sub 'System snapshot'
try {
    $si = $script:sysInfo
    Row 'Hostname'       $si.hostname
    Row 'OS'             "$($si.os.caption)  Build:$($si.os.build)"
    Row 'Admin'          "$($si.is_admin)  |  64-bit: $($si.is_64bit_proc)  |  PS: $($si.ps_version)"
    Row 'CPU'            "$($si.cpu.name)  Cores:$($si.cpu.cores)/$($si.cpu.threads)  Max:$($si.cpu.max_mhz)MHz"
    Row 'RAM'            "$($si.ram.total_gb) GB  Running:$($si.ram.running_mhz)MHz  Rated:$($si.ram.rated_mhz)MHz  XMPmismatch:$($si.ram.xmp_mismatch)"
    $si.gpu | ForEach-Object { Row 'GPU' "$($_.name)  Driver:$($_.driver_ver)  $($_.driver_date)  VRAM:$($_.vram_mb)MB  @$($_.current_hz)Hz/$($_.max_hz)Hz" }
    $si.storage | ForEach-Object { Row 'Disk' "$($_.model)  $($_.size_gb)GB  [$($_.type)]  Free:$($_.free_pct)%" }
    Row 'BIOS'           "$($si.bios.vendor) $($si.bios.version)  $($si.bios.date)  SecureBoot:$($si.bios.secure_boot)  TPM:$($si.bios.tpm)  Virt:$($si.bios.virt_enabled)"
    Row 'Power plan'     $si.power_plan
    Row 'AV products'    (if ($si.security.antivirus) { $si.security.antivirus -join ', ' } else { 'Unknown' })
} catch {}

Sub 'Known limitations'
if ($script:limitations.Count -gt 0) {
    $script:limitations | ForEach-Object { W "  - $_" }
} else { W '  None recorded.' }

Sub 'All findings (for AI)'
foreach ($sev in $sevOrder) {
    $group = @($script:findings | Where-Object { $_.Severity -eq $sev })
    foreach ($f in $group) {
        W ("  [{0}|{1}] {2} :: {3}" -f $f.Severity, $f.Confidence, $f.Category, $f.Title)
        if ($f.Evidence)      { W "    Evidence: $($f.Evidence)" }
        if ($f.Recommendation){ W "    Fix:      $($f.Recommendation)" }
    }
}

Sub 'Recent changes summary (last $EventDays days)'
$si2 = $script:sysInfo.recent_changes
W "  Windows Updates: $(@($si2.updates).Count) entries"
W "  Driver changes:  $(@($si2.driver_changes).Count) entries"
W "  Crashes/KP41:    $(@($si2.crashes).Count) entries"
$si2.crashes | ForEach-Object { W "  CRASH: [$($_.time)] $($_.type) $($_.file)" }
FlushBuf

# ============================================================
# AI INSTRUCTION BLOCK
# ============================================================
Sec 'Z03' 'AI INSTRUCTION BLOCK' 'Read by the AI -- not for end users'
W ''
W '  *** AI -- READ THIS BEFORE ANALYSING ***'
W ''
W '  1. This report was generated by a read-only diagnostic script.'
W '     No system changes were made during the scan.'
W '  2. The JSON sidecar file (same name, .json extension) contains'
W '     structured data for reliable programmatic parsing.'
W '  3. Prioritise findings in this order: Critical > High > Medium > Low.'
W '     Within each tier, prefer Confidence=High findings over Medium/Low.'
W '  4. Cross-reference the recent_changes timeline with the user''s'
W '     reported "problem started" date to identify likely triggers.'
W '  5. Findings with Confidence=Low may be false positives. Do NOT'
W '     recommend disruptive actions (e.g. uninstalling drivers) based'
W '     solely on Low-confidence findings.'
W '  6. Do NOT recommend reinstalling Windows unless:'
W '     a) Multiple Critical/High-confidence findings indicate OS corruption,'
W '     b) BSOD + SMART failure + Kernel-Power 41 events are all present, OR'
W '     c) The user has already exhausted driver/settings fixes.'
W '  7. If admin=false in the header, the report is incomplete. Request'
W '     the user re-run the script with administrator rights.'
W '  8. Limitations listed in Z02 indicate data the script could not collect.'
W '     Do not make assumptions about data that was unavailable.'
W '  9. REDACTED fields (if present) mean the user chose -Redact mode.'
W '     Do not request the redacted values unless strictly necessary.'
W ' 10. The user symptom template (user_problem_template.txt, if present)'
W '     describes what the user reported. Correlate findings with symptoms.'
W ''
FlushBuf

# ============================================================
# JSON SIDECAR REPORT
# ============================================================
$script:sysInfo.limitations = @($script:limitations)
$script:sysInfo.findings    = @($script:findings | ForEach-Object {
    [ordered]@{
        severity       = $_.Severity
        confidence     = $_.Confidence
        category       = $_.Category
        title          = $_.Title
        evidence       = $_.Evidence
        recommendation = $_.Recommendation
    }
})

$jsonFile = [System.IO.Path]::ChangeExtension($OutFile, '.json')
try {
    $script:sysInfo.report_txt = $OutFile
    $jsonContent = $script:sysInfo | ConvertTo-Json -Depth 8 -Compress:$false
    Set-Content -Path $jsonFile -Value $jsonContent -Encoding UTF8 -ErrorAction Stop
    Write-Host "JSON: $jsonFile" -ForegroundColor Cyan
} catch {
    Write-Host "WARNING: JSON report could not be written: $($_.Exception.Message)" -ForegroundColor DarkYellow
}

# ============================================================
# USER SYMPTOM TEMPLATE
# ============================================================
if ($GenerateTemplate) {
    $templateFile = Join-Path $outDir 'user_problem_template.txt'
    $templateContent = @"
========================================================================
  USER PROBLEM REPORT TEMPLATE
  Fill this out and upload it together with the diagnostic report.
  Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm')
========================================================================

1. WHAT IS THE PROBLEM?
   (Describe the issue as precisely as possible)
   > 

2. SINCE WHEN?
   (Date / time when it first appeared, or 'always')
   > 

3. WHAT CHANGED BEFORE THE PROBLEM STARTED?
   (Driver update, Windows update, hardware swap, new software, etc.)
   > 

4. WHICH GAME / APP IS AFFECTED?
   (Or: 'all games', 'desktop only', 'only this game: ...')
   > 

5. EXACT ERROR MESSAGES / CODES
   (Copy the full text of any error popup or BSOD stop code)
   > 

6. HOW OFTEN DOES IT HAPPEN?
   (Always, random, only after X minutes, only at high load, etc.)
   > 

7. WHAT HAVE YOU ALREADY TRIED?
   (Driver reinstall, Windows repair, hardware swap, etc.)
   > 

8. SYSTEM TEMPERATURES WHEN PROBLEM OCCURS
   (CPU / GPU temp if known -- HWiNFO64, MSI Afterburner, etc.)
   > 

9. IS THE SYSTEM OVERCLOCKED?
   (CPU, GPU, RAM -- yes/no, and if yes, how)
   > 

10. ANY OTHER NOTES
    > 

========================================================================
"@
    try {
        Set-Content -Path $templateFile -Value $templateContent -Encoding UTF8 -ErrorAction Stop
        Write-Host "Template: $templateFile" -ForegroundColor Cyan
    } catch {
        Write-Host "WARNING: Could not write user template: $($_.Exception.Message)" -ForegroundColor DarkYellow
    }
}

Write-Host ''
Write-Host "DONE in $elapsed seconds." -ForegroundColor Green
Write-Host "TXT:  $OutFile" -ForegroundColor Cyan

# Final output-file validation: make sure we actually produced something
$finalSize = try { (Get-Item $OutFile -ErrorAction Stop).Length } catch { -1 }
if ($finalSize -le 0) {
    Write-Host 'WARNING: Output file is empty or missing after scan -- check disk space and write permissions!' -ForegroundColor Red
} else {
    Write-Host "Size: $([math]::Round($finalSize/1KB,1)) KB" -ForegroundColor Cyan
}

Write-Host "Findings: $($script:findings.Count) total  |  Limitations: $($script:limitations.Count)" -ForegroundColor Yellow
Write-Host ''
Write-Host 'Upload BOTH the .txt and .json files to your AI for best results.' -ForegroundColor DarkCyan
if ($GenerateTemplate) { Write-Host 'Also upload the user_problem_template.txt after filling it in.' -ForegroundColor DarkCyan }
if (-not $NoPause -and $Host.Name -eq 'ConsoleHost') {
    Write-Host ''
    Write-Host 'You can close this window. Press Enter to exit.' -ForegroundColor DarkGray
    try { [void][Console]::ReadLine() } catch {}
}
