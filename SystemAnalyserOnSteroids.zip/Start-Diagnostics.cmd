@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title Windows 11 Gaming Full Diagnostics

set "SCRIPT=%~dp0gaming_full_diagnostics.ps1"
if not exist "%SCRIPT%" (
  echo ERROR: gaming_full_diagnostics.ps1 was not found next to this launcher.
  pause
  exit /b 1
)

set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PSEXE%" set "PSEXE=powershell.exe"

"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" (
  echo.
  echo Diagnostics finished with exit code %ERR%.
  pause
)
exit /b %ERR%
